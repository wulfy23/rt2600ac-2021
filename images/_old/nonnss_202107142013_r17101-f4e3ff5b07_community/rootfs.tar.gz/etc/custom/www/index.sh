#!/bin/sh




















if [ "$REDIRECT_STATUS" = '404' ]; then


	if echo $REQUEST_URI | grep -q '/luci-static/'; then
		exit 0
	fi

	##########if echo $REQUEST_URI | grep '/resources/' | grep -q 'loading'; then exit 0; fi
	#[Fri May 21 17:04:51] LUCI[fail] [denied page 10.2.3.6 /resources/icons/loading.gif]
	#[Fri May 21 17:04:40] LUCI[fail] [denied page 10.2.3.6 /cgi-bin/resources/icons/loading.gif]
	if echo $REQUEST_URI | grep '/resources/' | grep -q 'loading.gif'; then exit 0; fi
	











	if echo $REQUEST_URI | grep -q '/ttyd'; then
	
		#NEEDSMOVINGTOSTDALONEFUNCTION
		########ASTERISKFAULTY if grep -q "$REMOTE_ADDR" "/tmp/.authlog.$(date +%Y%m%d%H)*"; then
		if grep -q "$REMOTE_ADDR" /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null; then
			###echo "remote:$REMOTE_ADDR /tmp/.authlog.$(date +%Y%m%d%H)STAR OK" > /dev/console
			REDIRECT_URL=http://ttyd.router
		else
			:
			#echo "remote:$REMOTE_ADDR /tmp/.authlog.$(date +%Y%m%d%H)STAR NOPE" > /dev/console
			#echo "grep \"$REMOTE_ADDR\" /tmp/.authlog.$(date +%Y%m%d%H)STAR" > /dev/console
		fi


	fi #NEWVARpossiblynotneeded_otherwiseactuallysays BadGateway








	if [ -z "$REDIRECT_URL" ]; then #hackforabove




	logger -t uhttpd "luci denied page $REMOTE_HOST $REQUEST_URI"
	echo "luci denied page $REMOTE_HOST $REQUEST_URI" >/dev/console





	fi







	#if echo $REQUEST_URI | grep -q '/luci-static/'; then
	#	exit 0
	#fi


fi



#luci denied page 10.2.3.155 /ttyd



















if [ ! -z "$REDIRECT_URL" ]; then

cat <<__EOF__
Content-type: text/html; charset=utf-8

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="refresh" content="0; URL=${REDIRECT_URL}" />
</head>
<body>
</body>
</html>
__EOF__
	exit 0
fi



























msgout() {
	echo "${1}" > /dev/console
	

	#HANDRUNONLY

	#if [ "$(dirname $0)" != "/www" ]; then
	#	echo "${1}"
	#fi

}
















HTTP_HOST=$(echo ${HTTP_HOST} | cut -d '.' -f 1)
HOST=$(echo ${HOSTNAME} | awk '{print tolower($0)}')






filterset() {
	while read THING; do
		case $THING in
			"PS"*|"LINENO"*|"HOSTNAME"*) continue; ;;
			"USER"*|"TERM"*|"SHLVL"*) continue; ;;
			"PPID"*|"PATH"*|"OPTIND"*) continue; ;;
			"IFS="*|"N="*|"'") continue; ;;
			"PWD="*|"HOME="*|"_C"*) continue; ;;
			"LOGNAME="*|"hlogfile"*|"_C"*) continue; ;;
			*) echo $THING; ;;
		esac
	done
}



if [ ! -z "$DEBUG" ]; then

	set | filterset > /dev/console

fi









######################################### Default url #URL=/cgi-bin/luci/admin/status/overview
#ORIGINAL URL=/cgi-bin/luci #note: various hostnames mean asks for a login again
#URL=/cgi-bin/luci/admin/status/overview









URL=/cgi-bin/luci

#@noREFERRERyetSOjustsendTOOVERVIEWifwethinkloggedin
if grep -q "$REMOTE_ADDR" /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null; then
	URL=/cgi-bin/luci/admin/status/overview
fi

















#NOTE: NEEDTOFIXREDIRECTS IF AUTHENTICATED (i.e.append REFERRER to cgi-bin/luci etc.@authcheck etc






if [ "${HTTP_HOST}" != "${HOST}" ] 
then 
    case ${HTTP_HOST} in
	

	###########################################################DEFAULTCASE-ISH
	#router|router.lan|editor) #only knowns first part of domain name so
	#	URL=/cgi-bin/luci
	#;;

	domain1)
		if [ -d /www/domain1 ]; then #TRYleaveINDEXoffBELOW URL=/domain1/index.html
	    		URL=/domain1/
		else
			echo "$0> nodir for $HOST @ /www/domain1" >/dev/console
	    	fi
	    ;;

    	#domain2)
	#    URL=/domain2/index.html
	#;;




	#NEED dirMSG function with contentandline
	downloads) #THISISDIRlnFILESnot/dlUI
		if [ -d /www/downloads ]; then
	    		#TRYleaveINDEXoffBELOW URL=/domain1/index.html
	    		URL=/downloads/
		else
			echo "$0> nodir for $HOST @ /www/domain1" >/dev/console
	    	fi
	    ;;



	editor|editor.router) #only knowns first part of domain name so
		if [ -d /www/editor ]; then
			#URL=/editor/pheditor.php
			URL=/editor/index.php
		else
			#echo "$0> nodir for $HOST @ /www/editor/pheditor.php" >/dev/console
			echo "$0> nodir for $HOST @ /www/editor/index.php" >/dev/console
	    fi
	;;


	


	dl|youtubedl|youtubedl.lan) #!?@dl?| dl.router|youtubedl|youtubedl.lan)
		if [ -d /www/dl ]; then
			#URL=/dl/index.php
			URL=/dl/
		else
			echo "$0> nodir for $HOST @ /www/dl/index.php" >/dev/console
	    fi
	;;





	#@@@experimental 202106 depends on appzip@9704modelonly+updatecheck.sh+index.sh
	############################################################################
	#due to mosquitto websocket-openssl vs full lib clash
	#note: updatecheck.sh is redirecting to ip/ttyd which is redirecting here
	############################################################################
	#@@@likely need authcheck here too
	############################################################################
	#netstat -lnap | grep tty | grep ESTABL
	#only br-lan only single connection
	######################################################################
	#may need to remove or disable user-manually installed ttyd init.d
	#or rename binary etc


	terminal|ttyd)
		#@updatecheck.sh #netstat -alnp | grep ESTABLISHED | grep ttyd

		#if [ ! -z "$(command -v ttyd)" ]; then
		
		if [ ! -z "$(command -v ttyd)" ] && \
		grep -q "$REMOTE_ADDR" /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null; then

			if [ -z "$(ps wwww | grep -v grep | grep ttyd)" ]; then
	


authisvalid() {
while read sLINE; do
	sID=$(echo $sLINE | cut -d' ' -f1)
	if ubus call session list | grep -q "$sID"; then
		return 0
	fi; return 1
done <<PPP
$(grep "$REMOTE_ADDR$" /tmp/.authlog.$(date +%Y%m%d%H) | sort | uniq)
PPP
}


#if authisvalid; then
#	(/usr/bin/ttyd -O -o -m 1 -p 0 -i br-lan -d 5 /usr/libexec/login.sh) &
#else
	(/usr/bin/ttyd -O -o -m 1 -p 0 -i br-lan -d 5 /bin/login) &
#fi

				thePID=$!

				sleep 1 #sleep 2<3<6
			fi

			CONNECTADDR=$(netstat -lnp | grep ttyd | tr -s '\t' ' ' | cut -d' ' -f4)
			#DBG set > /dev/console
			###########################URL=http://router:7681
			if [ ! -z "$CONNECTADDR" ]; then
				URL=http://$CONNECTADDR
				#DBG echo "addr: $URL" >/dev/console
			fi #else #keep default REFERRER would be better




			logger -t ttyd-init "ttyd-connection: $REMOTE_ADDR"

		fi


	;;




    esac
fi














if [ -n "$DEBUG" ]; then
echo "$0 HTTP_HOST:$HTTP_HOST HOST:$HOST HTTPS:$HTTPS URLFINAL:$URL REQUEST_URI:$REQUEST_URI" >/dev/console
fi




















htmlprint() {
	case "${1}" in
		head)
echo "Content-type: text/html"; echo ""


cat <<VVV
<!DOCTYPE html>
<html>
<head>
	<title>$SERVER_ADDR $(basename $0)</title>
</head>
<body>
	<h1>$SERVER_ADDR $(basename $0) $sACTION</h1>

<pre>
VVV
#<h1>apinfo</h1>
		;;


	foot)

cat <<'VVV'
</pre>
</body>
</html>
VVV


	;;

	esac

}

































specialcall() {

	#we should exit on matchifstdout


	local PARAM1="${*}"


	case "$PARAM1" in #case "$QUERY_STRING" in
		apinfo)


		htmlprint head
		for wNIC in $(iwinfo | cut -d' ' -f1 | tr -s '\t' ' ' | grep -v '^$'); do
			echo "############# iw dev $wNIC station dump $(iwinfo $wNIC info | grep 'Mode:')"
			iw dev $wNIC station dump
		done #iwinfo | cut -d' ' -f1 | tr -s '\t' ' ' | grep -v '^$'
		htmlprint foot

		exit 0



		;;
		*) #https://10.2.3.1/cgi-bin/getinfo.sh?something=apinfo #NOTE: OUTPUTisINHTML
			return 9
		;;


	esac
	exit 0


}







































#QUERY_STRING='dodo=fish'
#if [ "$REQUEST_METHOD" = "GET" ] && [ "$REQUEST_URI" != '/' ]; then
if [ "$REQUEST_METHOD" = "GET" ] && [ "$REQUEST_URI" != '/' ]; then

	case "$REQUEST_URI" in #>QUERY_STRING='dodo=fish'
		"/?"*)

			echo "$0 ASKED REQUEST_URI:$REQUEST_URI" >/dev/console
			if ! echo "$REQUEST_URI" | grep -q '='; then #>QUERY_STRING='dodo=fish'


				#@@@TESTFORALLLOWERCASEsanitizedl.sh

				SPECIALCALL=$(echo $REQUEST_URI | sed 's!\/?!!g')


				echo "specialcall $SPECIALCALL" > /dev/console
				specialcall $SPECIALCALL
			else
				echo "non-specialcall $REQUEST_URI" > /dev/console
			fi
			#specialcall apinfo

		;;
	esac

fi


































#echo "redirectto: ${URL}" >/dev/console
#@@@outputissuesomewhere echo "Content-type: text/html"; echo ""

cat <<__EOF__
Content-type: text/html; charset=utf-8

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="refresh" content="0; URL=${URL}" />
</head>
<body>
</body>
</html>
__EOF__














exit 0

























#ps wwww | grep -v grep | grep ttyd; lsof -i -nP | grep ttyd
#pgrep ttyd




