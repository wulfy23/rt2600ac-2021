#!/bin/sh
ecmd="echo "; i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then . /etc/custom/custfunc.sh; ecmd="echm ${i} "; fi
if [ -f /root/wrt.ini ]; then . /root/wrt.ini; fi










mountsmb() {

#SMBUSER="john"
#SMBPASSWD="smith"
#SMBUID="1000"
#SMBSERVER="10.2.3.6"
#SMBSHARE="downloads"
#SMBMNTPNT="/usbstick/downloads"


mount -t cifs -o username=${SMBUSER},password=${SMBPASSWD},uid=${SMBUID},forceuid,forcegid //${SMBSERVER}/${SMBSHARE} ${SMBMNTPNT}/

}



if [ ! -z "$SMBUSER" ] && \
	[ ! -z "$SMBPASSWD" ] && \
	[ ! -z "$SMBUID" ] && \
	[ ! -z "$SMBSERVER" ] && \
	[ ! -z "$SMBSHARE" ] && \
	[ ! -z "$SMBMNTPNT" ]; then


	
		if [ ! -z "$(mount | grep $SMBSERVER)" ]; then
			$ecmd "mountsmb: $SMBSERVER [mounted-already]"
		else
			$ecmd "mountsmb: $SMBSERVER $(mountsmb)"
			if [ ! -z "$(mount | grep $SMBSERVER)" ]; then
				$ecmd "mountsmb: $(mount | grep $SMBSERVER)"
			else
				$ecmd "mountsmb: $SMBSERVER [issues]"
			fi
		fi #$ecmd "mountsmb: $(mount | grep $SMBSERVER)"

fi






exit 0





