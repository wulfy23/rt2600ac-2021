#!/bin/sh










####################### @sysfixtime speedups ISNOTMOUNTED>reboot
#date -r /etc/banner -R #AEST>+10
#bannerlasttime=$(date -r /etc/banner)
#touch /etc/banner
#bannernewtime=$(date -r /etc/banner)
#echo "$0 touch /etc/banner [$bannerlasttime > $bannernewtime]" > /dev/console


















i="$(basename $0)"
SNAME="$i"



#DEBUG=1
#eval `grep ^RCDEBUG /root/wrt.ini 2>/dev/null`



#@@@ DEBUG then SLOG=SLd<tmp||/>/SLf
SLOG="/$SNAME.debug" #if ! -z "..." && -d "..." #/usbstick
#SLOG="/tmp/$SNAME.debug" #if ! -z "..." && -d "..." #/usbstick


SOUTPUTM="/dev/console"
SOUTPUTU="/dev/kmsg"







INIFILE="/root/wrt.ini"
if [ -f "$INIFILE" ]; then
    . "$INIFILE" || echo "$SNAME inifile: $INIFILE issue" > $SOUTPUTM
fi

if [ -n "$RCDEBUG" ]; then DEBUG=1; fi
[ -n "$DEBUG" ] && RCSLEEP=2
[ -n "$DEBUG" ] && logger -t $SNAME "DEBUG=1 $SLOG"


BACKSYS="/boot/backup"; mkdir -p $BACKSYS #OLD?
#LOGPERSIST (dirnotz)




#echo "shutdown.sh timingcheck start" > /dev/console












echSH() {

	DL=`date +%Y%m%d-%H%M%S`
	[ -n "$DEBUG" ] && echo "$i-$DL: ${*}" >> $SLOG
	#############@case DEBUG in console||&&logfiletmp||&&logfileroot...etc.etc.
	#############||case $SOUTPUTM in /dev/console /dev/kmsg *) if file ... ||stdout echo ||logger

	echo "$i> ${*}" >> $SOUTPUTM
	#echo "echSH-console-only@$i> ${*}" > /dev/console

	sleep ${RCSLEEP:-0}
}












echq() { echSH "echqcallfix||| ${*}"; }

if [ -n "$DEBUG" ]; then
	echo "shutdoen.sh DEBUGGING IS ON" > /dev/console
	echo "PPID: $PPID $(ps w | grep $PPID)" > /dev/console
	echo "init-DEBUGFILEis-$i-$DL: ${*} $SLOG" > /dev/console #init-DEBUGFILEis-shutdown.sh-: shutdown /tmp/shutdown.sh.debug lol
	#@@@ SOUTPUTM is /dev/console :) :) :)
	echo "init-NORMALFILEis-$i> ${*} $SOUTPUTM" > /dev/console
fi




[ -n "$DEBUG" ] && echq "DBG $(basename $0) ${*} pid:$(echo $$) ppid:$(echo $PPID)"



if [ -z "$1" ]; then
    echSH "[no-param1-exit]"; sleep 5; exit 0
fi









BOOTLOGd="/boot/backup/bootlogs"
DS="`date +%Y%m%d%H%M`"
















arewemounted() { #>custfunc.sh



	if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 1 ] && \
    	[ "$(mount | grep ' / ' | grep '(rw' | grep -v grep | wc -l)" -gt 0 ]; then

		: #debugprint
		return 0
	else
		: #debugprint
	fi





	#case "${*}" in *boot* *rootfs* x 2


	WAITMAX=11
    while [ "$(mount | grep ' / ' | grep '(ro' | grep -v grep | wc -l)" -gt 0 ]; do
        WAITCNT=${WAITCNT:-0}
		WAITCNT=0
        echo "$i waiting for rw-rootfs: $WAITCNT" >/dev/console
        sleep 1; if [ "$WAITCNT" -gt "$WAITMAX" ]; then break; fi; WAITCNT=$((WAITCNT + 1))
    done
    if [ "$(mount | grep ' / ' | grep '(ro' | grep -v grep | wc -l)" -gt 0 ]; then
        echo "$i waiting for rw-rootfs: $WAITCNT giving up" >/dev/console; return 1 #exit 0
	fi

	if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; then
    	WAITMAX=11
		WAITCNT=0
	    	while [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; do
            WAITCNT=${WAITCNT:-0}
            echo "$i waiting for rw-boot: $WAITCNT" >/dev/console
            sleep 1; if [ "$WAITCNT" -gt "$WAITMAX" ]; then break; fi; WAITCNT=$((WAITCNT + 1))
        done
    fi
    if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; then
        echo "$i waiting for rw-boot: $WAITCNT giving up" >/dev/console; return 2 #exit 0
	fi


}

















##################################################### um... too high || add logic || RCDEBUGLOGS=1 etc.
if [ -n "$RCDEBUG" ]; then
	mkdir -p "$BOOTLOGd"
	dmesg >> $BOOTLOGd/shutdown.sh-$1-dmesg-$DS
	logread >> $BOOTLOGd/shutdown.sh-$1-logread-$DS
fi
##################################################################################







gatherdebuginfo() {


if [ -n "$RCDEBUG" ]; then
	#ps w > /$0.testing.psw-on-shutdownatpersislogcalll
	echo "FIXME-LOGGINGTO/$0.abc" >/dev/console
	ps w > /$0.testing.psw-on-shutdownatpersislogcalll
fi

}















#1=sACTION plog||etc
#2=@@@sysstate cronsnap||boot||shutdown||other
#3=caller? $0 ... rc.d = fullpath...





case "$1" in


    fbootnoncommunityrestoretargz)
        :
        #called by? rc.local? early? late? < uci-defaults
        #no .firstboot && rc.local is stock &&|| profile.d/no-ashprofile.sh "isfboot" && "isnoncomm" then rclocal profile.d ...
    ;;




    install) #disabledorenabled ############################################################# UNUSED
		echSH "[heredocs-initdhooks-disabled-old]"; sleep ${RCSLEEP:-0}
		#writeinitdshutdownlate
		#writeinitdshutdownearly
	;;
    late)
		echSH "[late-ping]"; sleep ${RCSLEEP:-0}
		echSH "$(mount)"; logme "$(ps w)"
		echSH "$(pgrep -P 1 -a)"
	;;
	early)
		echSH "[early-ping]"; sleep ${RCSLEEP:-0}
		echSH "$(mount)"; logme "$(ps w)"
		echSH "$(pgrep -P 1 -a)"
	;;
    ############################################################# UNUSED


    #@@@ wrapper||&&cron> altsnap) persiststop persiststart x 2!!!>>> #@@@ persistX altsnap



    upgrade) #statisticsave|upgrade)




        #if uci show sqm | grep -q rpi4.qos; then #&& wrt.ini IPSET_SAVE
        #    if grep -q "^RPI4QOS_IPSETPERSIST" /root/wrt.ini 2>/dev/null; then
        #        echo "shutdown.sh upgrade ipsetsave /etc/init.d/sqm stop 2>/dev/null 1>/dev/null" > /dev/console
        #        echo "$(/etc/init.d/sqm stop)" > /dev/console
        ##########        #/etc/init.d/sqm stop 2>/dev/null 1>/dev/null
        #    fi
        #fi




		#if [ ! -d /tmp/rrd ]; then #@BROAD>>>per-service-stop||below all >/dev/null
        #		echSH "$SSNAME /tmp/rrd [nothing to backup]"; exit 0
		#else
            #20200911-POWERFAIL-ish EXTRA KEYPOINT PRINTS###########################################
            #[ -n "$DEBUG" ] && echSH "$SNAME> stopping nlbwmon|lucistats|collectd for clean data"
            echSH "stopping nlbwmon|lucistats|collectd for clean data"; #sleep 1
            ########################################################################################
            #20200911@@@~ifrunning?savingoveritself?whilestopped???


		if pidof nlbwmon 1>/dev/null; then
			[ -n "$DEBUG" ] && echSH "[running:$(pidof nlbwmon)]"
			NLBRUN=1
		else
			[ -n "$DEBUG" ] && echSH "prestop-nlbwmon [notrunning:$(pidof nlbwmon)]" #NLBRUN=0
		fi




		if [ ! -z "$NLBRUN" ]; then
			[ -x /etc/init.d/nlbwmon  ] && /etc/init.d/nlbwmon stop >/dev/null 2>&1
			while [ ! -z "$(pidof nlbwmon 2>/dev/null)" ]; do
				echSH "stop> nlbwmon [stop-wait]"; sleep 1
			done

            nlbw -c commit >/dev/null 2>/dev/null; sleep 2 #was3
            nlbw -c commit >/dev/null 2>/dev/null; sleep 2 #was3

			/etc/init.d/nlbwmon stop >/dev/null 2>/dev/null


			#NEWTESTINGTHIS->technically this is all we need to call? unless sysupgrade->backup-caseetal
			#then again realdir is in sysupgrade.conf so probably not needed... in case failed sysup

			#@@@ wrt.ini enabled etc ... >>> @psave call only

			[ -x /etc/init.d/persistentnlbwmon ] && /etc/init.d/persistentnlbwmon stop >/dev/null 2>/dev/null
			#@@@ persistnlb stop

		fi











		if pidof collectd 1>/dev/null; then
		    [ -n "$DEBUG" ] && echSH "statsrunning> NOTEHACK@collectd-pidof [stop]"; #sleep 1
            STATRUN=1
        fi

        /etc/init.d/luci_statistics stop >/dev/null 2>/dev/null
        /etc/init.d/collectd stop >/dev/null 2>/dev/null

	    #ALSONEW... in case of failed upgrade
	    [ -x /etc/init.d/persistentlucistatistics ] && /etc/init.d/persistentlucistatistics stop >/dev/null 2>/dev/null



        #(/etc/init.d/nlbwmon stop >/dev/null 2>/dev/null) &
        #(/etc/init.d/luci_statistics stop >/dev/null 2>/dev/null) &
        #(/etc/init.d/collectd stop >/dev/null 2>/dev/null) &
		#sleep 2 #??? dataintegrityneed>?wason:sleep 5

            #######@@@ ~!call persistl/n but sysupgrade stores real data dir aka...
            #######/etc/init.d/persistentlucistatistics; /etc/init.d/persistentnlbwmon
            ########ensure nothing is there on fboot||realbigger then snapitthen
            #######thiswouldneedextralogicinboot aka firstboot + restored data -lt 200b + backup WHERE??? nopersistentstorage!
		#fi



        if [ ! -z "$NLBRUN" ]; then
			[ -n "$DEBUG" ] && echSH "restart-2021-test-sysup-Tfix> nlbwmon [start]"; #sleep 1
            /etc/init.d/nlbwmon start >/dev/null 2>/dev/null
        fi

        if [ ! -z "$STATRUN" ]; then #@@@NOTE restart because 'start' issue re order (lucistat restart is enough leave collect)
			[ -n "$DEBUG" ] && echSH "restart-2021-test-sysup-Tfix> stats [start-re]"; #sleep 1
            /etc/init.d/collectd restart >/dev/null 2>/dev/null
            /etc/init.d/luci_statistics restart >/dev/null 2>/dev/null
	    fi






    ;;

    ################################################################ not much / anything is calling this anymore?
    ################################################################ !@reboot only halt?
    ################################################################ wrapper calls plog only I think

    #shutdown was initally called from... persistdata?
    #now wrapper calls... plog... need to log caller...





	#plog@persistendata shutdown ${UPGRADED}
    shutdown)


		echo "shutdown.sh-DBG-2021-FISHactualSHUTDOWNCALL ${*}" >/dev/console

		gatherdebuginfo "$1"




		#@2021 $0 plog psave
		#@2021?[ -x /etc/init.d/persistentlucistatistics ] && /etc/init.d/persistentlucistatistics stop >/dev/null 2>/dev/null



        #if uci show sqm | grep -q rpi4.qos; then #&& wrt.ini IPSET_SAVE
        #    if grep -q "^RPI4QOS_IPSETPERSIST" /root/wrt.ini 2>/dev/null; then
        #        ###/etc/init.d/sqm stop 2>/dev/null 1>/dev/null
        #        echo "shutdown.sh shutdown ipsetsave /etc/init.d/sqm stop 2>/dev/null 1>/dev/null" > /dev/console
        #        echo "$(/etc/init.d/sqm stop)" > /dev/console
        #    fi
        #fi



    ;;







	#plog
    plog) #init.d/persistdata?>LOGPERSIST? ######################################## init.d/persistdata boot|shutdown ~upgraded
                #LOGPERSIST (dirnotz)
		#PSAVEDIR@persistdata is the parentfolder for 'architecture' aka /boot
		#NEEDS CRONADD FROM INITD > added in 73-addcron
		#has rebootwrapper /boot > /restore files cp -u @@@NEEDS LOGPERSIST and LOGDIR vars
        	#=DIR if [ -z "$LOGPERSIST" ]; then
        #@@@ NOTANYMORE $2 cronsnap > dump + logread FLUSH? #@@@boot???rotate||sizecheck||aboveindbgdumps???





		


















	################################### WHOOPS MAY HAVE TRIGGERED FSCK@rootfs
	#if [ -z "$LOGPERSIST" ]; then
		#@@@>logONCE
		#@@@>crontabs/root 
	#	echo "20210399-LOGPERSIST[off] exit early hack" >/dev/console
	#	exit 0
	#fi

		######################################################################################
		##sed -i '\|/etc/init.d/acme start|d' /etc/crontabs/root
		######################################################################################
		#if [ -f "/etc/crontabs/root" ] && grep -q '/etc/init.d/acme' /etc/crontabs/root; then
		#ACMELINE=$(grep -n acme /etc/crontabs/root | cut -d':' -f1)
		#echo "ACMELINE: $ACMELINE"
		#sed -i "${ACMELINE} s!^!#!g" /etc/crontabs/root
		#####################################################################################












	#echo "shutdown.sh-DBG-2021-FISHPLOG ${*}" >/dev/console




	if [ "$2" = "boot" ]; then
		ISBOOT=1
	fi #@init.d/persistentdata $0 plog boot
	if [ "$2" = "psave" ]; then
		ISPSAVE=1
	fi #@cron plog psave








	arewemounted || PSAVEISSUES="${PSAVEISSUES} not-mounted"#exit 0 #arewemounted #usedtoexits #@@@"boot rootfs"

	if [ -z "$LOGPERSIST" ]; then
            PSAVEISSUES="${PSAVEISSUES} LOGPERSIST[empty]" #echSH "logpersist [empty]"
            #echo  "LOGPERSIST= EMPTY > exit 0"; exit 0
    else
	        : #echo  "LOGPERSIST: $LOGPERSIST"
    fi




	#gatherdebuginfo "$1" #THISDOESNOTHIN?2021TURNOFF@ro earlyboot
	################################ps w > /$0.PLOG.ATSHUTDOWNSH.testing.psw-on-shutdownatpersislogcalll






	eval $(grep '^localversion=' /etc/custom/buildinfo.txt 2>/dev/null)
	if [ -z "$localversion" ]; then localversion="unknown"; fi

	systemLF=$(uci get system.@system[0].log_file 2>/dev/null)
    if [ ! -z "$systemLF" ]; then #NOTUSED
		systemLFlines=$(cat $systemLF | wc -l)
	fi #echSH "systemLOGfile: $systemLF [$systemLFlines]" #@POSSIBLEEXITHERE





	[ -n "$DEBUG" ] && echSH "called from wrapper: ${*}" #echSH "called from init.d persistdata: ${*}"







	if [ ! -z "$PSAVEISSUES" ]; then echSH "psave issues: $PSAVEISSUES"; exit 0; fi

	#NOWLETSGETHAPPENING



		
	


	if [ ! -z "$ISPSAVE" ]; then #???


		#date -r /etc/banner -R #AEST>+10
		#date -r /etc/banner -I '+%Y%m%d_%H%M%S'
		############################################################################
		#@@@dhcp-ra?>toooften
		####################### topofthisscriptpostumount>rebootwrapper+here
		####################### @sysfixtime speedups ISNOTMOUNTED>reboot
		bannerlasttime=$(date -r /etc/banner)
		touch /etc/banner
		bannernewtime=$(date -r /etc/banner)
		echo "$0 touch /etc/banner [$bannerlasttime>$bannernewtime]" > /dev/console
		############################################################################


	fi












        mkdir -p "${LOGPERSIST}" || return 0
        DSTAMP=$(date +%Y%m%d%H%M)
        LOGLINES=$(logread | wc -l)

        #echo "DBG dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" > /dev/console && sleep 2

    if [ ! -f /tmp/.plogname ]; then
        OUTFILE="${LOGPERSIST}/plogread-${DSTAMP}-"
        if [ ! -z "${2}" ]; then OUTFILE="${OUTFILE}${2}-"; fi
        OUTFILE="${OUTFILE}${localversion}.log"
		echo $OUTFILE > /tmp/.plogname
	else
		OUTFILE=$(cat /tmp/.plogname)
	fi

	if [ ! -f "$OUTFILE" ]; then touch $OUTFILE; fi #@NOWPRETOUCHINGTHIS
	oLINES=$(cat $OUTFILE | wc -l)



	if [ ! -z "$ISBOOT" ]; then #@&&enabled
		echo "plog-saved-to: /boot/plog ${OUTFILE}" > /dev/kmsg #||logger
		#scrape up the remaining boot messages in case of power loss or no init.d/done/rc.local call
		(sleep 250 && /etc/custom/shutdown.sh plog psave) & #bonus-effect-will-call-sync

		#experimental needs scraper logic min 210seconds(150+)
		(sleep 230 && dmesg > $(dirname $OUTFILE)/pdmesg-${DSTAMP}-${localversion}.log) &

	fi



	if [ -f "${OUTFILE}" ]; then #incasemanuallydeletedandnamefromFLAGFILE
			if [ ! -z "$SHUTVERBOSE" ]; then #DOESNOTEXISTYETBUTALLTHISSTUFFISINPOSTMESSAGE
				echSH "pre-dump-size:$(du -cs ${OUTFILE} 2>/dev/null | head -n1) flines:$oLINES"
    		fi
	fi








	logfilter() {
		while read FISH; do
		case "${FISH}" in
			*"successfully loaded"*) :; ;; #collectdrubbush
			#*"Exiting normally."*) :; ;; #collectdrubbush
			*) echo $FISH; ;;
		esac
		done
	}

	logread | logfilter > /tmp/LOG #logread > /tmp/LOG

    nLINES=$(sed 'H;/LOGSAVED/h;$!d;x' /tmp/LOG | grep -v 'LOGSAVED' | wc -l)
    sed 'H;/LOGSAVED/h;$!d;x' /tmp/LOG | grep -v 'LOGSAVED' >> "${OUTFILE}"
	logger LOGSAVED

	rm /tmp/LOG 2>/dev/null






    #@@@@@@@@@@@@@ NOTETHISSHOULDBEONinit.dbootonly 2021OFFNOFIX@somethingearlyneedingtowrite?HIGHDELAYS sync
    #######echo "shut.sh SKIP-SYNC-POST-QUICKTEST" >/dev/console
	#NOPE@bootOROTHER-MOVEDOWNAFTERPLOGSYNC #####20210219tryagain #sync
    if [ -z "$ISBOOT" ]; then
		echo "shut.sh sync isboot:${ISBOOT:-"no"} ispsave:${ISPSAVE:-no}" >/dev/console
		DOSYNC=1 #sync
	fi

	oLINESN=$(cat $OUTFILE | wc -l)
	echSH "post-dump-size:$(du -cs ${OUTFILE} 2>/dev/null | head -n1) flines:$oLINESN[$nLINES]"






	######### FROM REBOOTWRAPPER BUT WOULD MISSCRON / POWERLOSS ETC #@@@RESTOREFILES #@@@ if -d /restorefiles
	#?CRON/SYSUP.CONFaddsHANDLED@?

	mkdir -p /restorefiles/plog
    cp -urf ${LOGPERSIST}/* /restorefiles/plog
	cp -urf /restorefiles/plog/* ${LOGPERSIST}/ #HAX-COPYNONEXISTBAK

    if [ -z "$ISBOOT" ]; then
		echo "shutdown.sh syncing $LOGPERSIST/ and /restorefiles/plog [sync]" > /dev/console
		DOSYNC=1



	else
		echo "shutdown.sh syncing $LOGPERSIST/ and /restorefiles/plog [nosync]" > /dev/console
	fi #20210225TESTWRAPPERHERE-SKIP-SYNC-ONBOOT 2021OFFNOFIX@somethingearlyneedingtowrite?HIGHDELAYS sync







	if [ ! -z "$DOSYNC" ]; then
		sync
	fi





	return 0 #|| continue &&||shift?

    ;;



    boot)
        [ -n "$DEBUG" ] && echSH "called from init.d persistdata: ${*}"
        echSH "DBGANYONECALLINGBOOT> called from init.d persistdata: ${*}"
    ;;






	*)
        [ -n "$DEBUG" ] && echSH "case-default:$1 [o]]"; sleep ${RCSLEEP:-0}
		#echSH "case-default:$1 [o]]"; sleep ${RCSLEEP:-0}
	;;

esac



[ -n "$DEBUG" ] && echSH "$SNAME $1 [complete]"



exit 0


[ -n "$DEBUG" ] && echSH "dbg sleep 3" && sleep 1











