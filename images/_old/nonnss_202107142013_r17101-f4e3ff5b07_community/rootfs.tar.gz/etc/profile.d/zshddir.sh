


if mount | grep ' / ' | grep -q '(ro'; then echo "rootfs-ro: mount -o remount rw /"; fi


eval $(grep '^RCSHDDIR=' /root/wrt.ini 2>/dev/null)

if [ -n "$RCSHDDIR" ]; then #echo "RCSHDDIR: $RCSHDDIR"; sleep 2
    if [ -d "$RCSHDDIR" ]; then #[ -d "$RCSHDDIR" ] && cd $RCSHDDIR
        cd $RCSHDDIR
    else
        logger -t "$(basename $0)" "/root/wrt.ini RCSHDDIR $RCSHDDIR [invalid]"
    fi
fi




eval $(grep '^RCSHBASH=' /root/wrt.ini 2>/dev/null)

if [ -n "$RCSHBASH" ]; then
    if [ ! -x "/bin/bash" ]; then
        logger -t "$(basename $0)" "/root/wrt.ini RCSHBASH /bin/bash [unavailable]"
    else #echo "RCSHBASH: $RCSHBASH"; sleep 2
        [ -z "$BASH_VERSION" ] && /bin/bash
    fi
fi #[ -n "$RCSHBASH" ] && [ -d "$RCSHDDIR" ] && cd $RCSHDDIR





