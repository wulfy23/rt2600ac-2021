#
# Copyright (C) 2016 lede-project.org
#


#we will need e2fsck in imageMakefile and COPY_BINplatform.sh > can live without short term...











synology_do_upgrade() {

	#THISISTHENULLIFIEDVERSION
	echo "sysupgrade temporarily disabled"	
	return 1

}

