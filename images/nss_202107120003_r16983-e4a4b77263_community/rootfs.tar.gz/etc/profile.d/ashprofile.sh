

cd /


if [ -f /root/ashprompt ]; then
	. /root/ashprompt
else
	export PS1='\[\e[1;32m\][\[\e[1;37m\]\u@\h \[\e[1;35m\]\w\[\e[1;32m\]]\[\e[1;31m\]\\$\[\e[m\] '
	#PS1='\[\033[35;1m\]\u\[\033[0m\]@\[\033[31;1m\]\h \[\033[32;1m\]$PWD\[\033[0m\] [\[\033[35m\]\#\[\033[0m\]]\[\033[31m\]\$\[\033[0m\] '
fi

if [ -f /root/ashaliases ]; then
	. /root/ashaliases
else
	:
fi
if [ -f /root/ashaliases ]; then
	. /root/ashfunctions
else
	:
fi


servicenew() {
	if [ "$1" = "list-enabled" ] && [ -z "$2" ]; then
		for F in /etc/init.d/* ; do
			$F enabled && echo "$F enabled"
		done;
	elif [ "$1" = "list-disabled" ] && [ -z "$2" ]; then
		for F in /etc/init.d/* ; do
			$F enabled || echo "$F disabled"
		done;
	elif [ -f "/etc/init.d/$1" ] && [ "$2" = "ubus" ]; then
		ubus call service list "{'name': '$1'}"
	elif [ -f "/etc/init.d/$1" ]; then
		/etc/init.d/$@
	else
		echo "Usage: service list-disabled|list-enabled|<service-name> [command|ubus]"
		if [ -n "$1" ]; then
			echo "service "'"'"$1"'"'" not found, the following services are available:"
			ls "/etc/init.d"
		fi
		return 1
	fi
}





#[ -x /bin/more ] || alias more=less
#[ -x /usr/bin/vim ] && alias vi=vim || alias vim=vi
#[ -x /usr/bin/arp -o -x /sbin/arp ] || arp() { cat /proc/net/arp; }
#[ -x /usr/bin/ldd ] || ldd() { LD_TRACE_LOADED_OBJECTS=1 $*; }





################################### up down arrow behavior /root/.inputrc ( non working )
#"\e[A":history-search-backward
#"\e[B":history-search-forward



#107 CONFIG_FEATURE_EDITING_HISTORY=255
#108 CONFIG_FEATURE_EDITING_SAVEHISTORY=y
#109 CONFIG_FEATURE_EDITING_SAVE_ON_EXIT=y











