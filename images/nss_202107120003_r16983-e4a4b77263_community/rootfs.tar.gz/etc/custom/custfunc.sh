#!/bin/sh
#1.1.2.3.4.6 add varcheckmulti
########################################################################################################
######################################### opK
#METAd="/root/meta" #METAd="/root/.meta"
#oMETAd="${METAd}/opkg"
#uMETAd="${METAd}/uci"
#bD="/restorefiles"
########################################################################################################
#bdest
########################################################################################################
















############################@@@updatecheck<>msgout "" debug >>> ISMAINTAINER~from-ucidefaults-000>base
#TESTING=1
#if ip -a link | grep -wq '00:11:32:96:42:65'; then TESTING="maintainer"; fi
#INMAINecho "$0 TESTING=\"maintainer\"" >/dev/console

















OUT_SPECIALTXT="/tmp/SPECIALTXT" #FORNOW-GENERAL-MAINTAINER-tmp-NOTIFY-STATIX>>> @SPECIALBOOT@mac/dev-match



#date +"%F_%H%M%S"
#eval `grep ^unique /etc/synoinfo.conf`
#model="$unique"
#logF="/ECMLLOG"					#comment this out later if ! -z then use logFd
logFd="${logFd:-/ECMD-LOG-DEFAULT}"		# is/was something already in wrt.ini if set...
#@@@ 20191127 testing w 61-preinitmod sourcing at top ... adding there did not add here? uncommented line below
iniFILE="/root/wrt.ini" #movetotoporoutetcincasenotgivenfornow
############### testing ini load after that set by if wrtdebug=y
#set -x




if [ -z "$iniFILE" ]; then echo "iniFILE-var-is-EMPTY > set > /root/wrt.ini" && iniFILE="/root/wrt.ini"; fi
if [ -f "$iniFILE" ]; then # FROM > inimainimportA > custfunc.sh.ini...
	#set -x
	. ${iniFILE}
	#set +x
	debugfboot="y"
else
	#SENDTOCONSOLE@S95soneecho echo "$0 ini import iniFILE: $iniFILE [no-exist]" #NOTE: $0 = sourcingscriptname
	echo "$0 (custfunc.sh)ini import iniFILE: $iniFILE [no-exist]" >/dev/console
	debug="n"; debugfboot="y"; wrtlogger="y" #SET ALOT MORE DEFAULT VARS HERE
fi









#DONTTHINKTHESEAREUSED@202105(wellfor7months)
################################################################# 20191001-001 testing all thes source here
if [ -f /etc/custom/custfunc.sh.iniget ]; then
	#echo "/etc/custom/custfunc.sh.iniget [import]"; sleep 2
	#set -x
	. /etc/custom/custfunc.sh.iniget
	#set +x
	inimainimportA
else
	#echo "custfunc.sh> /etc/custom/custfunc.sh.iniget [skip]"; #sleep 2
	echo "custfunc.sh> /etc/custom/custfunc.sh.iniget [skip]" >/dev/console
fi
#################################################################################### THIS IS WHERE wrtdebug etc is comingfrom!
if [ "$wrtdebug" = y ]; then
	#set -x
	: #$ecmd "wrtdebug: $wrtdebug > set -x"
	#VERBOSE=1
else
	: #$ecmd "wrtdebug: $wrtdebug > set +x or nothing"
fi





















LONCEf="/tmp/.onceonlyplease"


logONCE() {


    local SNAME="${i}"; if [ -z "$SNAME" ]; then SNAME="please-set-i"; fi #hackySNAMEorAUTOiPASSOVER



    if grep -xFq "$SNAME> ${1}" "${LONCEf:-"/tmp/fwcustomonce"}" 2>/dev/null; then
        #DBGisREPEAT echo "logONCEdbgtestingMSG-RPT> $SNAME ${1}" > /dev/console
        return 0
    fi





    ############################################logger -t $SNAME "${1}"
	#HACKY-CONSOLEONLY-THEREST-DBG-REPEATING
	echo "logONCEdbgtestingMSG-FIRSTMESSAGERETURNNOW> $SNAME ${1} /tmp/fwcustomonce" > /dev/console
    #echo "${SNAME}> ${1}" >> "${LONCEf:-"/tmp/fwcustomonce"}"
    echo "${SNAME}> ${1}" >> "${LONCEf:-"/tmp/.onceonlyplease"}"
	return 0





    logger -t $SNAME "${1}"
    echo "${SNAME}> ${1}" >> "${LONCEf:-"/tmp/.onceonlyplease"}"
	#echo "${SNAME}> ${1}" >> "${LONCEf:-"/tmp/fwcustomonce"}" #LONCEf="/tmp/.onceonlyplease"

	echo "logONCEdbgtestingMSG-FIRST> $SNAME ${1}" > /dev/console


	if [ "${2:-BUBBLE}" = "sysinfomsg" ]; then
		if [ -s /root/.sysinfo.msgs ]; then echo "$SNAME ${1}" >> /root/.sysinfo.msgs; fi
    fi

    return 0

}






#    if ! grep -xFq "$SNAME> ${1}" "${LONCEf:-"/tmp/fwcustomonce"}" 2>/dev/null; then
#        logger -t $SNAME "${1}"
#        echo "${SNAME}> ${1}" >> "${LONCEf:-"/tmp/fwcustomonce"}"
#
#		echo "logONCEdbgtestingMSG-FIRST> $SNAME ${1}" > /dev/console
#	else
#        echo "logONCEdbgtestingMSG-RPT> $SNAME ${1}" > /dev/console
#    fi






#NOTE best (sub)called from ecmd -> for now @firewall.custom +~ sqm_collectd.sh
########################WASABOVEcheckforrestore-ish
#########################docmd if ! grep prettyname in tmptxt the echo into tmptxt
#if [ ! -f /tmp/cakestatwarn ]; then
#	echo "Unknown qdisc type '$qdisc' on interface '$ifc'" 1>&2;
#	touch /tmp/cakestatwarn
#	fi










debugscriptCALL() { #NOTUSED>TBA@rcdebugandsourceherealloronceoffetc


	echo "FWCUST-DBG: PSwww-grepPID $(ps wwww | grep -v grep | grep $$)" > /dev/console
	echo "FWCUST-DBG: CMDLINE-$$: $(cat /proc/$$/cmdline)" > /dev/console
	echo "FWCUST-DBG: PPID-$PPID: $(cat /proc/$PPID/cmdline)" > /dev/console

}

#@@@stage2/stat
#PSVAL=$(ps w | grep -v grep | grep 'restart' | grep 'fw3')
#echo "PSVALnonrestart: $PSVAL" >> /dev/console
#$ecmd "PSVALnonrestart: $PSVAL"
#echo "FWCUST-DBG: ps w grep fw3: $(ps wwww | grep fw3 | grep -v grep)" > /dev/console


































echm() {


    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #system.@system[0].conloglevel='7' #@3 = nothingonconsole!!!
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!




    #$(/usr/bin/env sh if set -o | grep xtrace | grep -q on; then echo "silentTRACE"; fi)
    #env -u? ##>&2 echo "No sysupgrade found"
    #!see init.d/boot > ucidefload via src && rc.common subshell = no echo
    #       for file in $files; do
    #                ( . "./$(basename $file)"  ) && rm -f "$file"
    #                    done

    silenceECMD=y

    #ORGIMPORT if [ "$silenceECMD" == "y"  ]; then if set -o | grep xtrace | grep -q on; then TRACERESTORE=1; set +x; fi; fi
    #if [ "$silenceECMD" = "y"  ]; then









        ################WASON 20201030 OFF to TEST r14779-ish no console

        #if set -o 2>/dev/null | grep xtrace | grep -q on; then #if set -o | grep xtrace | grep -q on; then
        #    >&2 echo "------------------- seemetest ----------------------"
        #    TRACERESTORE=1
        #    set +x
        #fi












    #elif [ ! -f /tmp/.specialboot ]; then #firstuseofthishackytmpfile... debughereonlynow... slightly relates to ucidefaultsVAR
    #    echo "dbg-admin-once:somethingaboutecmdswithouttraces"
    #fi

LT="$(date +%Y%m%d%H%M%S)"

#if [ ! -f /etc/custom/.specialboot ]; then
#OUT_GENERAL="/dev/console" #dynamic BOOTSPECIAL || no console etc... OUT_GENERAL="/dev/console"
#else
OUT_GENERAL="/dev/kmsg"
#fi


#OUT_SPECIALTXT="/tmp/SPECIALTXT" #>>> MOVEOUTSIDEFUNCTION





#if [ ! -z "$ECMDVERBOSEDEBUG" ]; then
    #EXPORT set test
    if [ ! -f /tmp/.onceonlyplease ]; then
        #[ -t FISHMONGER ] && echo "FISHMONGER exported" >> $OUT_SPECIALTXT
        #[ -t SPECIALBOOT ] && echo "SPECIALBOOT exported" >> $OUT_SPECIALTXT
        #[ -t slp ] && echo "FUNCTION onlyonce present" >> $OUT_SPECIALTXT

        if [ ! -z "$WRTINILOADED" ]; then echo "WRTINIHASBEENLOADED" >> $OUT_SPECIALTXT; fi


        echo "OUT_SPECIALTXT: $OUT_SPECIALTXT" >> $OUT_SPECIALTXT

        touch /tmp/.onceonlyplease
    fi
    #[ -t SPECIALBOOT ] && echo "SPECIALBOOT exported" >> /tmp/ecmd.verbose.debug
#fi














###################################REFERENCE
#ecmd="echo "
#i=$(basename $0)
#.ini && ecmd="echm ${i} "
############################################


dologmsg=

logger=y
message="$2";
caller="$1";
shift 2;
slurp="0"; dots="0"; n=""; a=""; dslp="1"; eslp="0"









##################################3 20201030 floating >> SPECIALTXT lines... change to SPECIALTXT.early?


while [ "$#" -gt 0 ]; do
  case "$1" in
    #-n) n="-n "; shift 1;;
    #-d) dots="$2"; shift 2;;
    #-s) eslp="$2"; shift 2;;
    #-q) dslp="$2"; shift 2;;
    #-c) logger="n"; shift 1;;
    -n)
        n="-n "
        echo "PASSED -n ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 1
        echo "PASSED -n ${*} postshift $caller $message" >> $OUT_SPECIALTXT
        ;;
    -d)
        dots="$2";
        echo "PASSEDdots -d ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 2
        echo "PASSEDdots -d ${*} $caller $message postshift" >> $OUT_SPECIALTXT
        ;;
    -s)
        eslp="$2";
        echo "PASSEDsleep -s ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 2
        echo "PASSEDsleep -s ${*} $caller $message postshift" >> $OUT_SPECIALTXT
        ;;
    -q)
        dslp="$2";
        echo "PASSEDdslp?debugonly? -q ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 2
        echo "PASSEDdslp?debugonly? -q ${*} $caller $message postshift" >> $OUT_SPECIALTXT
        ;;
    -c)
        logger="n";
        echo "PASSEDloggerC?consoleonly? -c ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 1
        echo "PASSEDloggerC?consoleonly? -c ${*} $caller $message postshift" >> $OUT_SPECIALTXT
        ;;
	################################## 20191110 trying to add a logonly function
    -L)
        dologmsg="y";
        #logF="/$caller.log"		#### NB: this may have to be reset in logmsg to logFd
        logF="/tmp/custfunc.sh_z_ecmd_L_SILENT-$caller.log"		#### NB: this may have to be reset in logmsg to logFd
        echo "PASSED-L? log specifically ??? -L ${*} $caller $message" >> $OUT_SPECIALTXT
        #> /tmp/ecmd.verbose.debug
        shift 1
        ;;
    -*)
        echo "unknownoption1:$1 ${*} $caller $message" >> $OUT_SPECIALTXT
        echo "unknown option: $1 ... \
	need: -d dotno -s slpsec -n nonew -q dotsleep" >&2
        #exit 1
	;;
    *) msgadd="$msgadd $1"
        echo "notcallerormessageandunknown->msgaddISITUSEDLATER?:$1 ${*} $caller $message" >> $OUT_SPECIALTXT
        shift 1
        ;;
    #*) message="$1"; shift 1;;
    #*) msgadd="$msgadd $1"; shift 1;;
  esac
done







###############################################################################
##"cmd "ecmd-c-use" -c; sleep 1; "cmd "ecmd-c-use2"; sleep 1


####################!!!!!!!!!!!!!       ?SOURCED . OUTSIDE ECMD?
###### 20190732-movedoutsideofecmd for testing
#if [ -f /root/wrt.ini ]; then
#	. /root/wrt.ini
#	debugfboot="y"
#else
#	debug="n"; debugfboot="y"; wrtlogger="y"
#fi
#if [ -z "$wrtdebug" ]; then echo "inivar:wrtdebug:z:$wrtdebug" && wrtdebug="n"
###################### not-sure where ^ is sourcing from ini? so STATICTHESE-TMP-HERE >>> !!!!! ???   inimainimportA
debug="y"; #@?notusedanymore0936???
debugfboot="y";
debugsboot="y"; #~~~ startup enable kmsg
wrtlogkmsg="y"
wrtlogger="y"
wrtdebug="y"





###NOTE: fLag S means firstbootisfinished<notstartup... ! Script or Shell etc.
### R = root HOME
### L = 'login ppid/cmdline'
##################################################### NEWSTANDALONEVALUES
local ecmd_ISSSH=
if [ ! -z "$SSH_TTY" ]; then
	local ecmd_ISSSH=1
fi
#MUSTBEINTERACTIVE?






#FLAG: SIIRssh.2\#-ash NOT Fall or S.
#################################################################################################### 20200910-doubleloggerfix1
#SAMPLE if echo $PS1 | grep -q '@'; then fLag="${fLag}I"; fi #PS1='\w \$ ' or HOME='/' on non-interactive
#################################################################################################
if [ ! -f /root/.firstboot ]; then fLag="F"; else fLag="S"; fi

case $(cat /proc/$PPID/cmdline 2>/dev/null) in
	*"bash"*|*"/bin/bash"*|*"-ash"*|*"/bin/ash"*)
        SHELLBASED=1
        #ISINITMSG=
        fLag="${fLag}I"
        ;;
        #/bin/ash--login?IIRLsomewhere #bash>U
    #*"rc.common"*) :; ;; #@if echo ! $fLag | grep -q "S"; then fLag="${fLag}S"; fi #"sh/etc/custom/rc.custom"
	*"/sbin/procd"*)
        ISINITMSG=1
        PROCDBASED=1
	    fLag="${fLag}P";
    ;;
    *"sh/etc/rc.local"*) :
        ISINITMSG=1
	    RCLOCALBASED=1
	    INRCLOCAL=1
        fLag="${fLag}p";
    ;;


    #@@@PROBABLYTOOBROAD
    *"sh/etc/rc.common"*)
        ISINITMSG=1
        RCCOMMONBASED=1
	    fLag="${fLag}C";
    ;;



    ############################### startup... really need altvar to fLag < bSTAGEetc... put here and "chainpostlettersfornow"
    #*"sh/etc/rc.local@p
    *"sh/etc/custom/rc.custom"*)
        ISINITMSG=1
	    RCLOCALBASED=1
        fLag="${fLag}pC"
    ;;
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
#75-setupnetworkdefaultseth1:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> !TBA! wan-if-eth1>!config>[setup]rpi-netswitcher.sh-tmp
    *"sh/etc/custom/firstboot/"*) #is rc.custom > sh call
        ISINITMSG=1
	    RCLOCALBASED=1
	    fLag="${fLag}pC"; #set to pC same as rc.custom #NOTset to p now same as rc.local ? #fLag="${fLag}pC";
    ;;
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    ################################## 20201030 @ FU unknown
    *"sh/etc/custom/startup"*)
        ISINITMSG=1
	    RCLOCALBASED=1
	    fLag="${fLag}ps";
    ;;
    *) fLag="${fLag}U"; ;;  #UNKNOWNcaller
    #EXTRADEBUG.tmpfilehere*) fLag="${fLag}U"; ;;  #UNKNOWNcaller
esac







######################################### SC
###################################
#rc.local:SC.2\#/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> no commit: nothing or nochanges
#rc.local:SC.2\#/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> ############################################################## end rc.local







############ WASONHEREMOVEDTOEND
#fLag="${fLag}.${SHLVL}" 	#jumped to 5 6 and 7 on latest built was 2-5?
#if ps w | grep "$PPID" | grep -v grep | grep -q "login"; then fLag="${fLag}.c"; fi
########################### WASON MOVINGLOWER ( end )
#tr -cd '[a-z]'
#fLag="${fLag}.PPID:`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
################################################################


if echo $PS1 | grep -q '@'; then fLag="${fLag}I"; fi #PS1='\w \$ ' or HOME='/' on non-interactive
if echo $HOME | grep -q '/root'; then fLag="${fLag}R"; fi
if [ ! -z "$SSH_TTY" ]; then fLag="${fLag}ssh"; fi
#################################################################################################
if ps w | grep "$PPID" | grep -v grep | grep -q "login"; then fLag="${fLag}L"; fi #fLag="${fLag}.c"
fLag="${fLag}.${SHLVL}" 	#jumped to 5 6 and 7 on latest built was 2-5?









##############
#fLag="${fLag}.PPID:`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
fLag="${fLag}\#`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
#################################################################################################
#message="$fLag: $message"
#caller="$caller:$fLag"





#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!?????????????????????????????????
echo $n "${caller}:$fLag> ${message}" >> $OUT_SPECIALTXT


if [ "$dologmsg" == "y" ]; then logmsg "n: $n caller:${caller} fLag:$fLag> message:${message}"; return 0; fi # -L-logmsg-return
#logmsg "n: $n caller:${caller} message:${message}"

#INTERACTIVE echo stdout > else turned off! ########TESTINGTHISOFFTWOinLOGREADNOPE
################################################################################################### #WASON WASON WASON WASON WASON
#if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
#NEWERI if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
#####################################################################################################################
#NOTE first S||F subject to change ... S logic was based on /root/.firstboot > && wip if -z export?




##########if echo $fLag | grep -qE '(I|R)'; then echo INTERACTIVE$n "${caller}> ${message}"; fi
if echo $fLag | grep -qE '(SIIRL)'; then #if echo $fLag | grep -qE '(II)'; then
    : #CONSOLEANYWAY echo INTERACTIVE$n "${caller}> ${message}"; fi
elif echo $fLag | grep -qE '(I|R)'; then
    echo INTERACTIVE$n "${caller}> ${message}"
    #???????return 0
fi
#if echo $fLag | grep -qE '(I|R)'; then
	######echo $n "${caller}> ${message}"
	######if [ "${wrtlogger}" == "y" ]; then
	######	echo $n "> ${message}" | logger -t "${caller}"
	######fi
	#####echo $n "> ${message}" | logger -t "${caller}"
    #echo "${caller}> ${message}" > /dev/kmsg #echo $n "> ${message}" > /dev/kmsg
#fi



    #determineinitstate() {  }
    #STATEINIT= FBOOT STARTUP/1 STARTUP/rpt RUN SHUTDOWN #mix of many things... best to have seperate function












#MSGCLASS= RCLOCALBASED RCCOMMONBASED SHELLBASED #+ISINITMSG@all vs z or SHELLBASED
if [ ! -z "$RCLOCALBASED" ]; then
    MSGCLASS="rclocalbased"
elif [ ! -z "$SHELLBASED" ]; then
    MSGCLASS="shellbased"
########################################### 20201030TEST
elif [ ! -z "$ISINITMSG" ] && [ ! -z "$RCCOMMONBASED" ]; then #QUICKHACK
    MSGCLASS="rclocalbased" #@@@ rccommonbased <@
elif [ -z "$MSGCLASS" ]; then
    MSGCLASS="unknown"
fi








####################### rc.common done rc.local end SC
#ISINITMSG=1
#RCCOMMONBASED=1
#fLag="${fLag}C";












#case "$MSGCLASS" in
#esac
#echo "$MSGCLASS> $caller >>> $message" >> $OUT_SPECIALTXT
echo "$MSGCLASS> $caller $message" >> /tmp/debug-all-boot-msgs
#echo $n "${caller}:$fLag> ${message} FLAG: ${fLag} NOT Fall or S."












if [ -z "$ISINITMSG" ] && [ -z "$SHELLBASED" ]; then
    echo "NOTINITMSGorSHELLBASED> $MSGCLASS> $caller >>> $message" >> $OUT_SPECIALTXT
fi





if echo $OUT_GENERAL | grep -q '/dev/console'; then ######## if output is console then append time
    caller="[${LT}] ${caller}"
fi












case "${fLag}" in
	##### WORKAROUNDUNTILPERMSGSEPERATECASE-PER_OUTPUT DONOTHINGONCERTAIN MSGS(interactive-for-now)
	################# bash-ssh-interactive FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'
    "SIIRssh"*)
		:
	;;
    "F"*|"S."*|"SC"*|"FC"*) echo "${caller}> ${message}" >> $OUT_GENERAL; ;;
    #^^^^^^^^^^^^^^^^^^^^^^^?????????????????????????? #STARTUPWORKAROUNDSFORNOW "ps"*|"pC"*) #
	"Sp"*) #@@@STARTUPNOOUTPUT around post usbpi rollback???^^^ WTF? Sp SpC Sps? #echo "SP> ${caller}> ${message}" >> $OUT_GENERAL
        echo "${caller}> ${message}" >> $OUT_GENERAL
    ;;
    *) echo $n "${caller}:$fLag> ${message} FLAG: ${fLag} NOT Fall or S." >> /tmp/debug-boot-msgs; ;; #MAINTAINERUNMATCHEDif
esac






    ################################## 20201030
    #*"sh/etc/rc.common"*) :
	#    fLag="${fLag}C";
    #;;
	#*) fLag="${fLag}U"; ;;  #UNKNOWNcaller
	###################### TEMPDEBUGMORE

############ 20201030~persistentdata~add/mod return on no LOGPERSIST PSAVEDIR was not set... no fbootconsole...
############ ~?shutdown.shcalled?> initial logsave@bootearly?
#55-ctymodelb:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> updatecheck.sh flavour wrt.ini [present]
#NOTINITMSGorSHELLBASED> unknown> 55-ctymodelb >>> updatecheck.sh flavour wrt.ini [present]
#971-bdrunfboot:FpC.4\#sh/etc/custom/rc.custom2824> run /etc/custom/firstboot/4-model-b/75-setupnetworkdefaultseth1
#75-setupnetworkdefaultseth1:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> !TBA! wan-if-eth1>!config>[setup]rpi-netswitcher.sh-tmp
#NOTINITMSGorSHELLBASED> unknown> 75-setupnetworkdefaultseth1 >>> !TBA! wan-if-eth


############### unknown
#rc.local:SC.2\#/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> no commit: nothing or nochanges
#rc.local:SC.2\#/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> ###########











#	sleep $eslp
#sleep $dslp










    ################WASON 20201030 OFF to TEST r14779-ish no console

    #if [ "$silenceECMD" == "y"  ]; then if [ ! -z "$TRACERESTORE"  ]; then TRACERESTORE=; set -x; fi; fi





}









############ 20201030~persistentdata~add/mod return on no LOGPERSIST PSAVEDIR was not set... no fbootconsole...
############ ~?shutdown.shcalled?> initial logsave@bootearly?
#55-ctymodelb:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> updatecheck.sh flavour wrt.ini [present]
#NOTINITMSGorSHELLBASED> unknown> 55-ctymodelb >>> updatecheck.sh flavour wrt.ini [present]
#971-bdrunfboot:FpC.4\#sh/etc/custom/rc.custom2824> run /etc/custom/firstboot/4-model-b/75-setupnetworkdefaultseth1
#75-setupnetworkdefaultseth1:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> !TBA! wan-if-eth1>!config>[setup]rpi-netswitcher.sh-tmp
#NOTINITMSGorSHELLBASED> unknown> 75-setupnetworkdefaultseth1 >>> !TBA! wan-if-eth








#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#BASGssh FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.
#ASHssh FLAG: SIIRssh.2\#-ash NOT Fall or S
#Sp = rc.local
#SU = fboots
#NOTE first S||F subject to change ... S logic was based on /root/.firstboot > && wip if -z export?
#ABOVE I|R = INTERACTIVEWORKINGWELL




#[root@dca632 /usbstick 44°]# cat /etc/bash.bashrc  # System-wide .bashrc file # Continue if running interactively
#[[ $- == *i*  ]] || return 0
#[ \! -s /etc/shinit  ] || . /etc/shinit
#-s = not zero > ! -s = biggerthanzero




#INTERACTIVE echo stdout > else turned off! ########TESTINGTHISOFFTWOinLOGREADNOPE
#WASON WASON WASON WASON WASON
###############################################################################################################
#if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
###############################################################################################################
#NEWERI if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
#####################################################################################################################
#999-firstbootcomplete:F.4.PPID:sh/etc/custom/rc.custom2462> finito
#rc.custom:F.3.PPID:sh/etc/rc.local>  ################################### firstboot end 20200826-0457
#rc.local:S.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> no commit:  or nochanges
#rc.local:S.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> ############################################################## end rc.local
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> datadir: /restorefiles
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> gw-v4> [ok]
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> gw-v6> [ok]
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:S.2.PPID:-ashIRssh> datadir: /restorefiles
#checkinternet.sh:S.2.PPID:-ashIRssh> getting gw> attempts remaining: 1 every 0
#checkinternet.sh:S.2.PPID:-ashIRssh> gw-v4> [ok]
#checkinternet.sh:S.2.PPID:-ashIRssh> gw-v6> [ok]
#checkinternet.sh:S.2.PPID:-ashIRssh> NET_DEV4:eth1 NET_
#####################################################################################################################
########### startup
#[root@dca632 /usbstick 43°]# cat /tmp/debug-boot-msgs
#rc.custom:Sp.3\#sh/etc/rc.local> /bin/rpi-perftweaks.sh [run] FLAG: Sp.3\#sh/etc/rc.local NOT Fall or S.
#rc.custom:Sp.3\#sh/etc/rc.local>  ################################### startup init 20200828-0144 FLAG: Sp.3\#sh/etc/rc.local NOT F.
#rc.custom:Sp.3\#sh/etc/rc.local> /etc/custom/startup/* [run] FLAG: Sp.3\#sh/etc/rc.local NOT Fall or S.
#71-macrunstartup:SU.4\#sh/etc/custom/rc.custom2770> /etc/custom/dca632563177.sh startup [ok] FLAG: SU.4\#sh/etc/custom/rc.custom27.
#dca632563177.sh:SU.5\#sh/etc/custom/startup/71-macrunstartup> board MAC private SAMPLE: startup (firstboot|startup|shutdown|upgrad.
#71-macrunstartup:SU.4\#sh/etc/custom/rc.custom2770> /etc/custom/dca632563177-startup.sh [nope] FLAG: SU.4\#sh/etc/custom/rc.custom.
#996-boardrunstartup:SU.4\#sh/etc/custom/rc.custom2770> Model:4-model-b /etc/custom/startup/4-model-b [ok:2] FLAG: SU.4\#sh/etc/cus.
#996-boardrunstartup:SU.4\#sh/etc/custom/rc.custom2770> /etc/custom/startup/4-model-b/17-rpi-4-startup-sample [run] FLAG: SU.4\#sh/.
#996-boardrunstartup:SU.4\#
#####################################################################################################################
#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'
#+ echo 'SIIRssh.3\#/bin/bash'
#+ grep -qE '(I|R)'
#+ echo INTERACTIVE '99-pkgremovetxt> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]'
#INTERACTIVE 99-pkgremovetxt> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh] FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'
#+ read defPK
#+ grep -q ^zoneinfo-southamerica /tmp/instpkg.txt
#+ :
#####################################################################################################################
#996-boardrunstartup
#sh/etc/custom/rc.custom2770> /etc/custom/startup/4-model-b/17-rpi-4-startup-sample [run] FLAG: SU.4\#sh/.
#dca632563177.sh:SU.5\#sh/etc/custom/startup/71-macrunstartup> board MAC private SAMPLE: startup (firstboot|startup|shutdown|upgrad.
#####################################################################################################################







#getopt
#getopt [OPTIONS]
#
#Options:
#
#        -a,--alternative                Allow long options starting with single -
#        -l,--longoptions=longopts       Long options to be recognized
#        -n,--name=progname              The name under which errors are reported
#        -o,--options=optstring          Short options to be recognized
#        -q,--quiet                      Disable error reporting by getopt(3)
#        -Q,--quiet-output               No normal output
#        -s,--shell=shell                Set shell quoting conventions
#        -T,--test                       Test for getopt(1) version
#        -u,--unquoted                   Don't quote the output

























#vert@zr:/fs/sdd1/openwrt/RTNGext/cache/files-postinstall/files-community$ fgrep -r sysinfo.wrt .
#./etc/custom/firstboot/31-metareset:SYSINFO="/root/sysinfo.wrt"
#./etc/custom/wrt.ini:SYSINFO="/root/sysinfo.wrt"
#./etc/custom/custfunc.sh.iniget:SYSINFO="/root/sysinfo.wrt"
#./etc/custom/custfunc.sh.iniget:#SYSINFO="/root/sysinfo.wrt"














checkforsysteminfo() {

FN="checkforsysteminfo" #echo "##########################Creating /systeminfo $Dsetup"


#######echo "DBG: custfunc.sh-$FN> early SYSINFO: $SYSINFO" > /dev/console
#echo "DBG: custfunc.sh-$FN> $SYSINFO(wipvar)" > /dev/console
#######DBG: custfunc.sh-checkforsysteminfo> /root/sysinfo.wrt(wipvar)


if ! [ -f /systeminfo ]; then
	#writesysteminfo
	writesysteminfo > /systeminfo
elif [ -f /systeminfo ]; then
	if ! cat /systeminfo | grep -q "$REVISION"; then
		echo "/systeminfo revision has changed... regenerating"
		cp /systeminfo /systeminfo.old.$D
		#writesysteminfo
		writesysteminfo > /systeminfo
	fi
fi

}












writesysteminfo() {
    Dsetup=`date +%Y%m%d%H%M`
    echo "#########################################################"
	echo "MODEL=\"$MODEL\""
	echo "VERSION=\"$VERSION\""
	echo "REVISION=\"$REVISION\""
	echo "REVISIONs=\"$REVISIONs\""
	echo "TARGET=\"$TARGET\""
	echo "SETUPDATE=\"$Dsetup\""

BUILDINFOTXT="/etc/custom/buildinfo.txt"
FILESINFOTXT=".filesinfo"
#@CUMULATIVEINFOTXT="/etc/custom/cumulative.txt" >>> CINFOBUILD??? 55 maybe or rpi-support
if [ ! -f "$BUILDINFOTXT" ]; then
	infomsg="$infomsg $BUILDINFOTXT[no]"; issues=1 #leaving on here for debug but not written for here
else
    echo "###################################### buildinfo"
    cat "$BUILDINFOTXT" 2>/dev/null | grep -vE "(^$|^#)"
fi


if [ ! -f "$FILESINFOTXT" ]; then
    infomsg="$infomsg $FILESINFOTXT[no]"; issues=1
else
    echo "###################################### filesinfo"
    cat "$FILESINFOTXT" 2>/dev/null | grep "^FILESREVISION" #cat "$FILESINFOTXT" 2>/dev/null | grep -vE "(^$|^#)"
fi

if [ ! -z "$issues" ]; then
    echo "issues: $infomsg" >> $OUT_SPECIALTXT
fi #[ -n "$DEBUG" ] && $ecmd "issues: $infomsg"; sleep ${RCSLEEP:-0}; exit 0

}



revisionsimplify() {
    echo "$1" | cut -d "-" -f 0 | cut -d "+" -f 0 | tail -c +2
}
















getsysteminfo() {
#osreleaseFILE="/etc/os-release"
#if [ ! -f "$osreleaseFILE" ]; then infomsg="$osreleaseFILE[no]"; issues=1; fi
MODEL=$(cat /etc/board.json | jsonfilter -e '@["model"]["id"]')
VERSION=$(ubus call system board | jsonfilter -e '@["release"]["version"]')
REVISION=$(ubus call system board | jsonfilter -e '@["release"]["revision"]')
REVISIONs=$(revisionsimplify $REVISION)
TARGET=$(ubus call system board | jsonfilter -e '@["release"]["target"]') #note: bcm53xx/generic

checkforsysteminfo
}


#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!originallytohandle-?generalecmdonnoupgradeyet?
#WASON EVERYCALL MOVING TO >>>>>>>>>>> getsysteminfo <<<<<<<<<<<<< >>>??? uci-def vs firstboot-early-1||2
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!










sanitize_name() {
	sed -e '
		y/ABCDEFGHIJKLMNOPQRSTUVWXYZ/abcdefghijklmnopqrstuvwxyz/;
		s/[^a-z0-9_-]\+/-/g;
		s/^-//;
		s/-$//;
	' "$@"
}












cmdstovars() {
##########ls -lah /bin/ps | grep procps-ng
###########lrwxrwxrwx    1 root     root          17 Sep 26 20:15 /bin/ps -> /bin/procps-ng-ps*
	if ps --help 2>&1 | grep -q BusyBox; then PS="ps w"; else PS="ps aux"; fi
}












#FN="getFREEMULTI"; finfo "${*}";
finfo() {

if [ "$VERBOSE" -gt "2" ]; then
	echo "########################################################################"
	echo "$FN paramsno: $#"
	echo "$FN  allopts: $*"
	echo "########################################################################"
	echo ""
	#sleep 2
fi

}

















ucichangecheck() {

#1 change-main wireless|network etc #@@@2021needs -S@all$ecmdoptionORtoggleoutTO
                                    #@@@needs if ucichanges &>/dev/null; then uci changes commit -v or similar

docommit=
ucionlycheck=

case "${*}" in
	*"commit"*) docommit="y"; shift 1; ;;
	*)
			ucionlycheck="${ucionlycheck} $1"; shift 1;
	;;
esac

if [ ! -z "$ucionlycheck" ]; then
	for uciconfig in $ucionlycheck; do
		changes="`uci changes | grep "^$uciconfig." | wc -l`"
		if [ "$changes" -eq 0 ]; then
			echo "no $uciconfig changes: $changes"
		else
			havechanges="y"
			echo "############################ got $uciconfig changes: $changes"
			uci changes | grep "^$uciconfig."
			#uci commit $1
			#echo "uci commit $uciconfig [skip-pass-commit-to-function]"
		fi
	done
fi

if [ -z "$ucionlycheck" ]; then
    changetypes="`uci changes | cut -d'.' -f1`"
	if [ ! -z "$changetypes" ]; then
	    havechanges="y"
		uci changes | cut -d'.' -f1 | uniq | while read ucitype; do
			changes="`uci changes | grep "^$ucitype." | wc -l`"
			echo "########### changes for ucitype: $ucitype $changes" #; sleep 2
			uci changes | grep "^$ucitype."
			echo "##################################################" #; sleep 1

			#echo "uci commit $ucitype [skip pass commit to function]"; sleep 1
			#echo "uci commit $ucitype"; sleep 1
			#uci commit $ucitype
		done
	else
		echo "no-changes-of-any-type"
	fi
fi

if [ ! -z "$havechanges" ] && [ "$docommit" == "y" ]; then
	$ecmd "uci commit"; uci commit; sleep ${RCSLEEP:-0}
else #NOTE: a little noisy@rc.local
    $ecmd "no commit: ${docommit:-nothing} or nochanges"; sleep ${RCSLEEP:-0}
fi

}









pleaseConfirm() {
  prompt=${1:-'continue? [y/n] : '}
  while true; do
    read -p "${prompt}" yn
    case $yn in
      [Yy]* ) return 0;;
      [Nn]* ) return 1;;
      * ) echo 'Please answer y or n.';;
    esac
  done
}






################### from vpnbypass
#verbosity=2
#serviceName="something"
#readonly packageName='vpnbypass'
#readonly serviceName="$packageName $PKG_VERSION"

output() {
# Can take a single parameter (text) to be output at any verbosity
# Or target verbosity level and text to be output at specifc verbosity

	if [ $# -ne 1 ]; then
		if [ ! $((verbosity & $1)) -gt 0 ]; then return 0; else shift; fi
	fi
	[ -t 1 ] && echo -e -n "$1"
	local msg=$(echo -n "${1/$serviceName /service }" | sed 's|\\033\[[0-9]\?;\?[0-9]\?[0-9]\?m||g');
	if [ "$(echo -e -n "$msg" | wc -l)" -gt 0 ]; then
		logger -p 5 -t "${packageName:-service} [$$]" "$(echo -e -n "${logmsg}${msg}")"
		logmsg=''
	else
		logmsg="${logmsg}${msg}"
	fi
}

#	output "$__ERROR__: $serviceName failed to discover WAN gateway.\\n"; return 1;

#	config_get verbosity           'config' 'verbosity' '2'
#	if [ -z "${verbosity##*[!0-9]*}" ] || [ "$verbosity" -lt 0 ] || [ "$verbosity" -gt 2 ]; then
#		verbosity=1
#	fi








getOSsetupinfo() {

rDEVm="`cat /proc/mounts | grep '/dev/root' | cut -d' ' -f2`"
rDEVfs="`cat /proc/mounts | grep '/dev/root' | cut -d' ' -f3`"
rDEVo="`cat /proc/mounts | grep ' /overlay ' | cut -d' ' -f1`"
rDEVofs="`cat /proc/mounts | grep ' /overlay ' | cut -d' ' -f3`"
#rDEVo="`block info | grep 'MOUNT="/overlay"' | grep '/dev/sd' | cut -d':' -f1`"
#######################################3
#echo "           rDEVm: $rDEVm"
#echo "          rDEVfs: $rDEVfs"
#echo "           rDEVo: $rDEVo"
#echo "         rDEVofs: $rDEVofs"
#######################################



if [ "$rDEVm" = "/rom" ] && [ -z "$rDEVo" ]; then
    spaceDEV="`cat /proc/mounts | grep ' / ' | grep '/dev/sd' | cut -d' ' -f1`"
    if [ -z "$spaceDEV" ]; then
        otype="romonly"
	    spaceDEV=""
    else
        otype="romwblockroot"
    fi
elif [ "$rDEVm" = "/rom" ] && [ ! -z "$rDEVo" ]; then
	#echo "romoverlay"
	otype="romoverlay"
	spaceDEV="$rDEVo"
elif [ "$rDEVm" = "/" ] && [ -z "$rDEVo" ]; then
	#echo "usbroot"
	otype="usbroot"
	spaceDEV="/"
else
	otype="unknown"
	#echo "unknown" && exit
fi


#echo "otype: $otype spaceDEV: $spaceDEV"


}



################################################################ opK has quasi half newer versions^
#findrootfsdev
#
















serviceisenABLES() {
    readlink -f /etc/rc.d/*$1
}









altcopymethod() {
mkdir -p /tmp/introot
mkdir -p /tmp/extroot
mount --bind / /tmp/introot
mount /dev/sda1 /tmp/extroot
tar -C /tmp/introot -cvf - . | tar -C /tmp/extroot -xf -
umount /tmp/introot
umount /tmp/extroot
}







somethign() {
    mount /rom -o remount,rw
lsmod | grep -Ei 'sd_mod|usb-storage|ext4'
}







































################################################################################################## 20210355
#@@@rc.local check against 'on-rom' version @fboot? + qos-debug similar functions




filesumchk() {



	local FN="filesumchk"
	local F_PATH="${1}"
	local F_SUM="${2}"


	
	#@if -f?<need replace file anyway i.e. print hash on 1 param only?
	local F_PATHn="${2}"
	local F_ERR=
	local F_MSG=
	local F_MSGd=




	local copy_file="y"



	###MANUALONLY local DEBUG=1
	if [ ! -z "$DEBUG" ]; then $ecmd "$FN-debug: ${*}"; sleep ${RCSLEEP:-0}; fi






	if [ ! -e "${F_PATH}" ] ; then F_ERR="${F_ERR} s!F:${F_PATH}"; fi
	if [ ! -e "${F_PATHn}" ] ; then F_ERR="${F_ERR} c!F:${F_PATHn}"; fi
	


	################### PARAM2 as HASH or Z?(print) NOT SUPPORTED IMPLIES KNOWN alt-cp 'rom'
	#ASSUMES-DEFAULT-PATH-WHERE-TO-FIND-NEWFILES aka rom/F_PATH || /etc/custom/$F_PATH
	#if [ ! -z "$F_PATHn" ] && [ "$(echo ${F_PATHn} | wc -c)" = 33 ]; then #32(33w/n?) echo ${F_PATHn} | wc -c
	#	echo "param2ismd5: $F_PATHn" #all sorts of whacky logic below
	#	#set F_PATHn later
	#	exit 0
	#elif [ ! -z "$F_PATHn" ] && [ "$(echo ${F_PATHn} | wc -c)" = 32 ]; then
	#	echo "param2ismd5: $F_PATHn" #all sorts of whacky logic below
	#	#set F_PATHn later
	#	exit 0
	#elif [ ! -e "${F_PATHn}" ] ; then
	#	F_ERR="${F_ERR} c!F:${F_PATHn}"
	#fi









	if [ ! -z "${F_ERR}" ]; then $ecmd "$FN> $F_ERR"; return 0; fi
	






	local F_PATHs="${F_PATH}_save_$(date +%Y%m%d%H%M)"		#PATHtoCOPYoriginalASbackup







		old_md5=$(md5sum ${F_PATH} 2>/dev/null | awk ' { print $1 ; } ' )
		current_md5=$(md5sum ${F_PATHn} 2>/dev/null | awk ' { print $1 ; } ' )



		#F_MSG="${F_MSG} onsys:${F_PATH}:$old_md5"
		#F_MSG="${F_MSG} onrom:${F_PATHn}:$current_md5"
		
		
		F_MSG="${F_MSG} onsys:${F_PATH}"
		F_MSG="${F_MSG} onrom:${F_PATHn}"



		F_MSGd="${F_MSGd} oS:$old_md5"
		F_MSGd="${F_MSGd} oR:$current_md5"



		if [ -z "$current_md5" ] || [ -z "$current_md5" ] ; then
			F_MSG="${F_MSG} z-md5"
			copy_file="n"
		elif [ "$current_md5" = "$old_md5" ] ; then
			F_MSG="${F_MSG} [match]"
			copy_file="n"

		else
			copy_file="y" #defaultattop?orig
			F_MSG="${F_MSG} [update]"
		fi





	if [ ! -z "$DEBUG" ]; then
		$ecmd "DBGSUMMARY-$FN> $F_MSGd"
	fi




	if [ "$copy_file" = "y" ] ; then #echo "DBG-i> cp ${2} ${1} [on ret 1???]"
		
		F_MSG="${F_MSG} backupto: ${F_PATHs}"
		$ecmd "$FN> $F_MSG" 

		$ecmd "$FN> cp ${F_PATH} ${F_PATHs} [backup]"
		cp ${F_PATH} ${F_PATHs}
		#GETsZAPPEDNEXTINSTALLsilently(ucidef/01-statecheck EARLY!!!) try to put into restorefiles too)
		cp ${F_PATH} /restorefiles/$(basename ${F_PATHs}) 2>/dev/null
		$ecmd "$FN> cp ${F_PATHn} ${F_PATH} [replace]"
		cp ${F_PATHn} ${F_PATH}

		return 1

	else
		#DBG $ecmd "$FN> $F_MSG" #$ecmd "NOCHANGEorISSUES?> $FN> $F_MSG" 
		##### $ecmd "DBG-$FN> cp ${F_PATHn} ${F_PATH} $F_MSG [nochange]"
		##########################################$ecmd "DBG-$FN> ${F_PATHn} ${F_PATH} $F_MSG"
		####$ecmd "DBG-$FN> $F_MSG"
		$ecmd "$FN> $F_MSG"
		return 0
	fi




}



#PROPER filesumchk "/etc/rc.local" "/etc/rc.local.copy"



##################################################################################################33
##################################################################################################33
##################################################################################################33


























################################################## from umodin.shWAS>runmake_preinitmodin.sh aka >preinit/init< blockdo...
#!!!!!!!! NOT CALLED BY ANYTHING !!!!!!!!! > opkgupdchk<opK is similar
################################################## from umodin.shWAS>runmake_preinitmodin.sh
################################################## from umodin.shWAS>runmake_preinitmodin.sh
binsrequired="/sbin/block \
/usr/sbin/blkid
/usr/sbin/losetup \
/usr/sbin/fdisk \
/usr/sbin/fsck.ext4"

do_bin_check() {

for check_bin in $1; do #for check_bin in $binsrequired; do
    if [ -x "$check_bin" ]; then
        echo "$check_bin [ok]"
    else
        echo "$check_bin [nope]"
    fi
done

}

################################# #from *.sh < .
#do_bin_check "$binsrequired"
#################################





################################################## from umodin.shWAS>runmake_preinitmodin.sh




############################      WAS INSIDE OF echm moved here 20190732 to test # IMPORTANTVARSSHOULDHAVEFALLBACKS
if [ -z "$wrtdebug" ]; then echo "inivar:wrtdebug:z:$wrtdebug" && wrtdebug="n"; fi




################################################# echoL from ip6setmanual.sh > has console detection not used
#scriptN="`basename $0`"
echoL() {
if [ "$TERM" == "linux" ]; then
	echo "${*}" > /dev/console
else
	$ecmd "${*}"
fi
logger -p 6 -t $i "${*}"
}
################################################# echoL from ip6setmanual.sh > consoledetectionnotused
#^ADDHEREANDUSETHIS? logecmlF="/ECMLLOG"	#ADDED testing seperateintegrated $ecmdwlog/justlog etc...






logmsg() { #WAS loggy from ash profile debugging standalone stuff somewhere # /root/.profile aka ash extra rc

#set -x

#logFd
############### TEMPORARY SO WE WARN that ecmd -L was called but no previous setting of logF variable
#NEVERMATCHES this?
if [ -z "$logF" ]; then echo "PLEASE SET logF=\"somenameorpath\" in SCRIPTS locally" >> $logFd; fi

if [ -z "$logF" ]; then logF="$logFd"; fi

if [ -z "$HDR" ]; then
	if [ ! -z "$i" ]; then HDR="${HDR} $i"; else HDR="no-i-set"; fi
fi

if [ "$TERM" == "linux" ]; then isconsole="y"; fi



echo "${HDR:-$0} $*" >> $logF



#echo "$HDR $*" > /dev/console #WILLSTILLSENDTOCONSOLE-aka-NOT-ash-related
#echo "$HDR $*" >> /PROFILELOG
#logger -t $HDR "$HDR $*"


#################################################### reset the logF variable for the next call
#if [ ! -z "$logF" ]; then logF="$logFd"; fi
logF=



#set +x

}














#DOME@@@ THIS NEEDS anti -x option



######################## echm ( or unlikely inigET needs and if -n












































































#date '+%d %b %Y %T' --date="@$(($(date +%s)+230))" #plus230secs









skipifrestore() {
if [ -f /restore.tar.gz ]; then
	$ecmd "skipping as /restore.tar.gz found > (notreally just to test)"
	#touch
	#exit 0
else
	$ecmd "DBG no /restore.tar.gz so we can run... "; sleep 2
fi
}





##########################################################################################
#@@@ please retestwithtput bin unsure if tested yet aka working
#if [ "$dots" -gt 0 ]; then
#	for f in `seq 1 $dots`; do echo -n $gdot && sleep $q; done; echo ""
#fi
##########################################################################################
#/dev/console
#/dev/ttyMSM0
#@+ 20190936>rc.local no show on console pre-this but shows in log... = kmsg switches post login?
#if [ ! -f /root/.firstboot ]; then echo $n "${caller}> ${message}" > /dev/console; fi
#if [ ! -f /root/.firstboot ]; then echo $n "${caller}> ${message}" > /dev/ttyMSM0; fi





########################################################################################################
#../rt2600ac/>base-files/custom/etc/custom/bin/wrtrestoreback:	wrtchkmnt "${bpart}" "${bmnt}"
#../rt2600ac/>/base-files/custom/etc/custom/bin/wrtsnapback:	wrtchkmnt "${bpart}" "${bmnt}"
################################# 1:device 2:mountpoint


wrtchkmnt() {
bpart="${1}"
bmnt="${2}"
bdev="`echo $bpart | cut -d'/' -f3`"

mount | grep $bpart | cut -d' ' -f3 | grep -q $bmnt
if [ $? -eq 0 ]; then
	#echo "already mounted";
	return 0
else
	if [ ! -d $bmnt ]; then
		echo "Mount point does not exist... creating $bmnt"
		mkdir -p $bmnt
	fi

	cat /proc/partitions | grep -q $bdev
	if [ $? -ne 0 ]; then echo "Device: $bdev does not exist" && return 6; fi
	mount | grep $bmnt | cut -d' ' -f3
	if [ $? -ne 0 ]; then
		echo "Mount point has another device mounted there"
		return 6
	fi

	mount | cut -d' ' -f3 | grep -q $bmnt
	if [ $? -eq 0 ]; then
		echo "Something else is mounted here already"
		mount | cut -d' ' -f3 | grep $bmnt
		exit 7
	fi

	mount $bpart $bmnt >/dev/null 2&>1; sleep 3
	mount | grep -q $bpart
	if [ $? -eq 0 ]; then
		echo "Mounted $bpart on $bmnt"
		return 0
	else
		echo "Unable to mount backup partition"
		return 1
	fi
fi

}
########################################################################################################


ismounteD() {

#1 is /dev/sda2 or whatever #returns mountpoint if is? or 0 or 1? later or ask?
bpart="${1}"
#bmnt="${2}"
#bdev="`echo $bpart | cut -d'/' -f3`"
mPT="`mount | grep $bpart | cut -d' ' -f3`"
#block info | grep "MOUNT" | grep $bpart
if [ ! -z "$mPT" ]; then
	echo "$mPT"
fi

}



ismounteDormount() {

#20200731>duplicateofwrtchkmnt&&wrtchkmntng?
#1 is /dev/sda2 or whatever
#returns mountpoint if is? or 0 or 1? later or ask?

bpart="${1}"
bmnt="${2}"
bdev="`echo $bpart | cut -d'/' -f3`"

mPT="`mount | grep $bpart | cut -d' ' -f3`" #echo "mount | grep $bpart | cut -d' ' -f3 | grep -q $bmnt"
#block info | grep "MOUNT" | grep $bpart
if [ ! -z "$mPT" ]; then
	echo "$mPT"
else
	:
fi

mount | grep $bpart | cut -d' ' -f3 | grep -q $bmnt
if [ $? -eq 0 ]; then
	echo "already mounted";
	return 0
else
	if [ ! -d $bmnt ]; then
		echo "Mount point does not exist... creating $bmnt"
		mkdir -p $bmnt
	fi

	cat /proc/partitions | grep -q $bdev
	if [ $? -ne 0 ]; then echo "Device: $bdev does not exist" && return 6; fi
	mount | grep $bmnt | cut -d' ' -f3
	if [ $? -ne 0 ]; then
		echo "Mount point has another device mounted there"
		return 6
	fi

	mount | cut -d' ' -f3 | grep -q $bmnt
	if [ $? -eq 0 ]; then
		echo "Something else is mounted here already"
		mount | cut -d' ' -f3 | grep $bmnt
		exit 7
	fi

	mount $bpart $bmnt >/dev/null 2&>1
	sleep 3
	mount | grep -q $bpart
	if [ $? -eq 0 ]; then
		echo "Mounted $bpart on $bmnt"
		return 0
	else
		echo "Unable to mount backup partition"
		return 1
	fi
fi


}









slpN() { #@dbgwanup > all integrateintoslpreal

	#echo "DBGslp:$1:$2" #DEBUGGING so I know called
	case "$1" in
		0) return 0; ;;
		1) sleep 0; ;;
		2) sleep 0; ;;
		3) sleep 0; ;;
		*) sleep ${RCSLEEP:-0}; ;;
	esac

}




############################################################20190737
slpA=1 # message-section-block pause
slpB=2 # full section pause
slpC=3 # long pause likely warning






slp() {

if echo "$*" | grep -q ' -t '; then
	tabPRINT="y"
else
	tabPRINT="n"
fi

#elif [ "$nSTATE" -eq 1 ] && [ "$1" != "-n" ] || [ "$1" != "-N" ]; then  #-N means the final N
if [ "$1" == "-n" ]; then
	nSTATE=1
	#echo "nSTATE: $nSTATE";
	shift 1
else
	#WASJUSTTHIS nSTATE=0 # no -n(appendORnew) and no -N(finish-nSTATEof1AKAlastwas-n)
	if [ "$1" == "-N" ]; then
		nSTATE=2 #aka TRYING 2 means use -n or no \n printf cause more to come
		shift 1;
	else
		#NO -n NO -N so JUST echo with newline
		nSTATE=0 # no -n(appendORnew) and no -N(finish-nSTATEof1AKAlastwas-n)
	fi
	#@@@BINGO    WILL PROBABLY NEED if 2 then step down to 1 or does the fallback to 0 work anyway???
fi


if [ ! -z "$2" ]; then
	if [ "$nSTATE" -eq 1 ]; then

		#@@ well should recignise -tANYWHERE and set y this bit is off and untestedasconfiseditwithnonewlineonsubsequent-N
		#if [ "$tabPRINT" == "y" ]; then
			#printf 'PFn-nT %50s: %s' "$2"
		#else
		#	echo -n "PFNt: $2"
		#fi

		#echo -n "dbgN-$nSTATE: $2";
		printf 'PFn-n: %50s: %s' "$2"
	else
		if [ "$nSTATE" -eq 2 ]; then
			printf 'PFn-N%s' "$2" # -N passed no newline
		else
			printf 'PF %s\n' "$2" # -N not passed or regular slp ... possible BUG THERE see BINGO
		fi


		#if [ "$tabPRINT" == "y" ]; then
		#echo "$2";
		#echo "dbgn-$nSTATE: $2";
		#printf 'PFn %23s: %s\n' "$2" "$state"
		#LASTREAL printf '%s\n' "$2"
	fi
fi


#echo "DBGslp:$1:$2" #DEBUGGING so I know called
case "$1" in
	0) return 0; ;;
	1) sleep 0; ;;
	#1) sleep $slpA; ;;
	2) sleep 0; ;;
	#2) sleep $slpB; ;;
	3) sleep 0; ;;
	#3) sleep $slpC; ;;
	*) sleep 0; ;;
	#*) sleep 1; ;;
esac

}

#slp 2 "TESTINGSLEEP2-with-message" #regular sleep with newline
#slp -n 2 "TESTINGSLEEP2-with-message" #startprintnonewline
#slp -N 2 "TESTINGSLEEP2-with-message" #middleprintnonewline
#@@@ -tANYWHERE="space-aligned"........






dirNFROMwrtbootgen() {
slp -n 2 "     $2-$1: "
if [ -d "$1" ]; then
	slp 1 " [found]"
else
	slp -N 2 " [create]"
	mkdir "$1"
	if [ "$?" -eq 0 ]; then
		slp 1 " [ok]"
	else
		slp 1 " [error]"
		exit 77
	fi
fi
}





reportmemorystats() {
	mem_total="$(awk '/^MemTotal/ {print int($2/1000)}' "/proc/meminfo" 2>/dev/null)"
	mem_free="$(awk '/^MemFree/ {print int($2/1000)}' "/proc/meminfo" 2>/dev/null)"
	#if ([ ${mem_total} -lt 64 ] || [ ${mem_free} -lt 40 ]); then
		echo "  mem-total: ${mem_total}"
		echo "   mem-free: ${mem_free}"
	#fi
}


psversion() { if ps aux &>/dev/null; then PSCMD="ps -w"; fi }

dfversion() { if ps aux &>/dev/null; then PSCMD="ps -w"; fi }






#####################################################################################################
### ALL UNUSED >>> use opK instead
####################################################################################### 202007+helpers

chkonline() { ##### from updatecheck.sh < zdossh.sh
#1 verbose
#@@@yoda-hotplug-wan@@@checkinternet.sh<dnscycle||CURLopkg@@@wanmonitor

if [ "$1" = "verbose" ]; then local VERBOSE=1; fi
if ! ping -c 2 -w 3 "8.8.8.8" &>/dev/null; then
    [ -n "$VERBOSE" ] && echo "no internet"
    return 1
fi
if nslookup ratburger.com 2>&1 | grep -qE '(NX|no servers could be reached)'; then
    [ -n "$VERBOSE" ] && echo "no dns"
    return 1
fi
return 0
}

#echo $0-$1 no-internet #showthelastresultmaybe 2>/dev/null aka 'defer'
#nslookup ratburger.combantrun NAMESERVER 2>&1 | grep -qE '(NX|no servers could be reached)' && return 1


chkpkg() {


if [ -z "$1" ]; then return 1; fi

#chkonline


}
#[ -z "$(opkg info iptables-mod-quota2|grep installed)"  ] && echo "xt_quota2 module is not installed." && opkg update && opkg install iptables-mod-quota2


########################################################################################################
### ALL UNUSED END
########################################################################################################
########################################################################################################











########################################################################################################
# END LIVE FUNCS

















sysvmdisplay() {

	local sysDIR="${1}"
	if [ -z "$sysDIR" ]; then sysDIR="/proc/sys/vm"; fi

	for sysvmF in $(find "${sysDIR}"); do

		if [ -d "$sysvmF" ]; then
			echo "dir: $sysvmF"
			continue
		fi

		if [ ! -r "$sysvmF" ]; then
			echo "$sysvmF [no-read-permission]"
			continue
		fi


		echo -n "$sysvmF: "; cat $sysvmF

	done

}













###################################################################################!/bin/sh

########################
#"228" #228MB
#"180" #180MB
#echo "234192 = 228.7M"
#minSPACEwarn="$(($minSPACEwarnMB * 10 * 100))"
#minSPACEexit="$(($minSPACEexitMB * 10 * 100))"

######################### REAL
minSPACEwarnMB="9000" #4GB   #LARGER then EXITMB!
minSPACEexitMB="6000" #6GB   #IF bck HAS LESS THAN THIS EXIT
minSPACEwarn="$(($minSPACEwarnMB * 10 * 100))"
minSPACEexit="$(($minSPACEexitMB * 10 * 100))"
##############################################
#echo "$minSPACEwarn minSPACEwarn"
#echo "$minSPACEexit minSPACEexit"
#echo "$minSPACEwarnMB minSPACEwarnMB"
#echo "$minSPACEexitMB minSPACEexitMB"
##############################################







spacecheckMULTI() {          #zos-sh-spacecheck-2.1 > v3

FN="spacecheckMULTI"
#SpChVERBOSE="y"
SpChVERBOSE="n"

###  TO BE FIXED OR REMOVED ETC ###########################################################################
#if [ -z "$1" ] || [ -z "$2" ]; then echo "$FN not enough parameters" && return; fi
#if $2 is NaN?
if [ "$#" -lt 3 ]; then #if [ "$#" -eq 0 ]; then
	#echo "$FN PARAMETERSPASSED incorrect" && return #	#usage; #exit
	echo "$FN PARAMETERSPASSED incorrect"
fi

while [ "$#" -gt 0 ]; do
	case "$1" in
	-c) comment="${2}"; shift 2;;
	-C) SpChTYPE="${2}"; shift 2;;
	-mFW) minFwarn="${2}"; shift 2;;
	-mFE) minFexit="${2}"; shift 2;;
	-d) SpChDEV="${2}"; shift 2; ;;
	-m) SpChMNT="${2}"; shift 2; ;;
	-*) echo "Unknown option -$1"; shift 1;;
	*) echo "Unknown option-* $1"; shift 1;;
	esac
done

if [ "$SpChVERBOSE" == "y" ]; then
	echo "   comment: $comment"
	echo "  SpChTYPE: $SpChTYPE"
	echo "   SpChDEV: $SpChDEV"
	echo "   SpChMNT: $SpChMNT"
	echo "  minFwarn: $minFwarn"
	echo "  minFexit: $minFexit"
fi


case "$SpChTYPE" in


	dev)
		echo "################################################### CHECKspaceONdev: $SpChDEV"
		echo "space-check-on-dev-notyetimplemented"
		return
	;;

	mpoint)

		echo "################################################### CHECKspaceONmnt: $SpChMNT"
		#GOOD BUTTOOMANY MATCHED WITH /

		#percentUSED="`df -T | grep -v Used | grep " $SpChMNT" | tr -s "\t" " " | cut -d' ' -f6 | sed 's/%//g'`"
		#bytesFREE="`df -T | grep "$SpChMNT" | tr -s "\t" " " | cut -d' ' -f5`"

		percentUSED="`df -T | grep -v tmpfs | grep -v Used | grep " $SpChMNT" | tr -s "\t" " " | cut -d' ' -f6 | sed 's/%//g'`"
		bytesFREE="`df -T | grep -v tmpfs | grep "$SpChMNT" | tr -s "\t" " " | cut -d' ' -f5`"

		#Filesystem           1K-blocks      Used Available Use% Mounted on
		#/dev/root              7224824    198336   6643104   3% /
		#tmpfs                   238292      4112    234180   2% /tmp
		#tmpfs                      512         0       512   0% /dev

	;;

	*)
		echo "SpChTYPE: unknown: $SpChTYPE"

	esac

if [ "$SpChVERBOSE" == "y" ]; then
	echo "        percentused: $percentUSED"
	echo "             MBfree: $(($bytesFREE / 100 / 10))" #echo "          bytesfree: $bytesFREE"
	echo "             GBfree: $(($bytesFREE / 1000 / 100 / 10))"
	echo "      minSPACEwarnMB: $(($minFwarn / 100 / 10))" #minSPACEwarnMB: $(($minFwarn / 1000 / 8))
	echo "      minSPACEexitMB: $(($minFexit / 100 / 10))" #minSPACEexitMB: $(($minFexit / 1000 / 8))
	echo ""
fi

if [ "$bytesFREE" -lt "$minFwarn" ]; then
	echo "WARNING-SPACELIMITED: space is below warning-level: $bytesFREE < $minFwarn"
fi

if [ ! -z "$minFexit" ] && [ "$bytesFREE" -lt "$minFexit" ]; then
	echo "WARNING-SPACETOOSMALL: space is below exit-level: $bytesFREE < $minFexit"
	echo "EXITING...$comment "
	#exit 17
fi


}

####################################################################################
#slp 2 "Checking for space on backup-mountpoint: $bckmnt"
#spacecheckMULTI -C "mpoint" -mFW "$minSPACEwarn" -mFE "$minSPACEexit" -c "commenttext" -m "$bckmnt"
#####################################################################################################







detectOStype() { #V-mid-wrtsomething... hdd?

dirPFX="`basename $0`"
if cat /proc/version | grep -q 'OpenWrt'; then runningOS="OpenWrt"; else runningOS="synology"; fi
if [ "$runningOS" == "OpenWrt" ]; then
	if [ -f "/rom/note" ]; then
		#slp 1 "/rom/note exists";
		if df -h | tr -s "\t" " " | grep -q '/dev/root '; then
			OSinsttype="hdd"
			bckmnt="/"
		else
			OSinsttype="initramfs"
		fi
	else
		OSinsttype="standard" #OStype="initramfs"
	fi
fi

if [ "$OSinsttype" == "initramfs" ]; then
	if [ "$srcdir" == "/" ] || [ "$srcdir" == "" ]; then
		if [ -z "$bckmnt" ]; then
			:
		fi
	fi
fi

}
#echo ${runningOS:-unset}
#echo ${OSinsttype:-unset}




fUNKYdebug() {
SpChVERBOSE="y"
if [ "$SpChVERBOSE" == "y" ]; then
	echo "######################################################################## $SHELL"
	echo "$FN paramsno: $#"
	echo "$FN  allopts: $*"
	echo "########################################################################"
	echo ""; sleep 1
fi
}



#################################################
# 20191110> ~na # /root/.profile ashextrarc
loggyorg() {

################## should we make HDR local to the sourcing script here? #HDR="ashshell-root.profile `date`"
#if -z HDR then HDR="$0-..."
echo "${HDR:-$0} $*"

if [ "$TERM" == "linux" ]; then
	echo "$HDR ${*}" > /dev/console
fi
#echo "$HDR $*" > /dev/console #WILLSTILLSENDTOCONSOLE-aka-NOT-ash-related
echo "$HDR $*" >> /PROFILELOG
logger -t $HDR "$HDR $*"
}















##################################################!/bin/bash
inipull() { #@?
#$1 inifile
#$2 varname
GOTVAR=$(sed -n -E -e '/^VERSION ?=/ s/.*\= *//p' "$1" | tr -d '"[:cntrl:]')
if [ -n "$GOTVAR" ]; then
	: #echo "retrieved $2 = $GOTVAR"
else
	: #echo "$2 = notset"
fi
REALVAR="`eval 'printf "%s\n" "${'"$2"'}"'`" #echo "$REALVAR"
#echo -n "$2 CURRENT:$REALVAR ini:$GOTVAR"
if [ "$REALVAR" == "$GOTVAR" ]; then
	echo "$REALVAR"
else
	echo "$GOTVAR"
fi
}
#VERSION=$(inipull "$INIFILE" "VERSION"); echo "POSTIMPORT VERSION: $VERSION"
















#seconds2days() { # convert integer seconds to Ddays,HH:MM:SS
#  printf "%ddays,%02d:%02d:%02d" $(((($1/60)/60)/24)) \
#  $(((($1/60)/60)%24)) $((($1/60)%60)) $(($1%60)) |
#  sed 's/^1days/1day/;s/^0days,\(00:\)*//;s/^0//' ;
#} #seconds2days $1; seconds2days $(date +%s); seconds2days $(( $(date +%s) + 86400 ))"

secondstodays() { #!/usr/bin/env sh                                                          ***
#if ls -la /bin/date | grep -q 'busybox'; then date -d "@$(( $(date +%s) + 86400 ))"; else date -d "+1days"; fi
if ls -la /bin/date | grep -q 'busybox'; then date -d "@$(( ${1} + 86400  ))"; else date -d "+1days"; fi
}








#sed -i 's:/etc/rc.local:#/etc/rc.local:g' /lib/upgrade/keep.d/base-files-essential












#checkinternet.sh:SIIRL.3#/bin/ash--login> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SIIRL.3#/bin/ash--login> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:SIIRssh.2#-ash> datadir: /restorefiles
#checkinternet.sh:SIIRssh.2#-ash> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:SIIRssh.2#-ash> gw-v4> [ok]
#checkinternet.sh:SIIRssh.2#-ash> gw-v6> [ok]
#checkinternet.sh:SIIRssh.2#-ash> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SIIRssh.2#-ash> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:SUIRssh.3#bash> datadir: /restorefiles
#checkinternet.sh:SUIRssh.3#bash> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:SUIRssh.3#bash> gw-v4> [ok]


#############3 with mod2 console out
#checkinternet.sh:SI.2.PPID:-ashIRssh> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SI.2.PPID:-ashIRssh> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:SI.2IRssh.PPID:-ash> datadir: /restorefiles
#checkinternet.sh:SI.2IRssh.PPID:-ash> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:SI.2IRssh.PPID:-ash> gw-v4> [ok]
#checkinternet.sh:SI.2IRssh.PPID:-ash> gw-v6> [ok]
#checkinternet.sh:SI.2IRssh.PPID:-ash> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SI.2IRssh.PPID:-ash> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:SIIR.4.PPID:/bin/bash> datadir: /restorefiles
#checkinternet.sh:SIIR.4.PPID:/bin/bash> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:SIIR.4.PPID:/bin/bash> gw-v4> [ok]
#checkinternet.sh:SIIR.4.PPID:/bin/bash> gw-v6> [ok]
#checkinternet.sh:SIIR.4.PPID:/bin/bash> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SIIR.4.PPID:/bin/bash> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> datadir: /restorefiles
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> gw-v4> [ok]
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> gw-v6> [ok]
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:SUIRL.3.PPID:/bin/ash--login> NET_DEV6:eth1 NET_ADDR6:2403:5


#5: wlan0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN mode DEFAULT group default qlen 1000
#    link/ether dc:a6:32:56:31:78 brd ff:ff:ff:ff:ff:ff
#    rc.common:F.1.c.PPID:/sbin/procd> ping1> friendly neighborhood uci-default script
#    rc.common:F.1.c.PPID:/sbin/procd> rc.local [ok:wc:144:wcV:37]
#    rc.local:F.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> vanilla
##    rc.local:F.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> ############################################################## startl
#    rc.custom:F.3.PPID:sh/etc/rc.local> /bin/rpi-perftweaks.sh [run]
#    rc.custom:F.3.PPID:sh/etc/rc.local>  ################################### firstboot init 20200826-0457
#    01-sysctl:F.4.PPID:sh/etc/custom/rc.custom2462> tba
#    02-wrtini:F.4.PPID:sh/etc/custom/rc.custom2462> wrt.ini exists in /root [keep]
#    11-userenv:F.4.PPID:sh/etc/custom/rc.custom2462> > Found bash
#    11-userenv:F.4.PPID:sh/etc/custom/rc.custom2462> Syncing /etc/custom/bash to /root/[root-orig-saved]
#    11-userenv:F.4.PPID:sh/etc/custom/rc.custom2462> N










#[ -t 1 ] && echo -e -n "$1"
#local msg=$(echo -n "${1/$serviceName /service }" | sed 's|\\033\[[0-9]\?;\?[0-9]\?[0-9]\?m||g');




















echmokversion() {





    if [ "$silenceECMD" == "y"  ]; then if set -o | grep xtrace | grep -q on; then TRACERESTORE=1; set -x; fi; fi






dologmsg=

logger=y
message="$2";
caller="$1";
shift 2;
slurp="0"; dots="0"; n=""; a=""; dslp="1"; eslp="0"
while [ "$#" -gt 0 ]; do
  case "$1" in
    -n) n="-n "; shift 1;;

    -d) dots="$2"; shift 2;;
    -s) eslp="$2"; shift 2;;
    -q) dslp="$2"; shift 2;;

    -c) logger="n"; shift 1;;


	################################## 20191110 trying to add a logonly function
    -L)
        dologmsg="y";
        #logF="/$caller.log"		#### NB: this may have to be reset in logmsg to logFd
        logF="/tmp/custfunc.sh_z_ecmd_L_SILENT-$caller.log"		#### NB: this may have to be reset in logmsg to logFd
        shift 1;;


    -*) echo "unknown option: $1 ... \
	need: -d dotno -s slpsec -n nonew -q dotsleep" >&2;
	#exit 1
	;;
    *) msgadd="$msgadd $1"; shift 1;;
    #*) message="$1"; shift 1;;
    #*) msgadd="$msgadd $1"; shift 1;;
  esac
done



####################!!!!!!!!!!!!!       ?SOURCED . OUTSIDE ECMD?
###### 20190732-movedoutsideofecmd for testing
#if [ -f /root/wrt.ini ]; then
#	. /root/wrt.ini
#	debugfboot="y"
#else
#	debug="n"; debugfboot="y"; wrtlogger="y"
#fi
#if [ -z "$wrtdebug" ]; then echo "inivar:wrtdebug:z:$wrtdebug" && wrtdebug="n"



###################### not-sure where ^ is sourcing from ini? so STATICTHESE-TMP-HERE >>> !!!!! ???   inimainimportA
debug="y"; #@?notusedanymore0936???
debugfboot="y";
debugsboot="y"; #~~~ startup enable kmsg
wrtlogkmsg="y"
wrtlogger="y"
wrtdebug="y"



###NOTE: fLag S means firstbootisfinished ! Script or Shell etc.
### R = root HOME
### L = 'login ppid/cmdline'







##################################################### NEWSTANDALONEVALUES
local ecmd_ISSSH=
if [ ! -z "$SSH_TTY" ]; then
	local ecmd_ISSSH=1
fi
#MUSTBEINTERACTIVE?

#FLAG: SIIRssh.2\#-ash NOT Fall or S.





#################################################################################################### 20200910-doubleloggerfix1
#SAMPLE if echo $PS1 | grep -q '@'; then fLag="${fLag}I"; fi #PS1='\w \$ ' or HOME='/' on non-interactive
#################################################################################################
if [ ! -f /root/.firstboot ]; then fLag="F"; else fLag="S"; fi



case $(cat /proc/$PPID/cmdline 2>/dev/null) in
	*"bash"*|*"/bin/bash"*|*"-ash"*|*"/bin/ash"*) fLag="${fLag}I"; ;; #/bin/ash--login?IIRLsomewhere #bash>U
	#*"rc.common"*) :; ;; #@if echo ! $fLag | grep -q "S"; then fLag="${fLag}S"; fi #"sh/etc/custom/rc.custom"
	*"/sbin/procd"*) :
	    fLag="${fLag}P";
    ;;
    *"sh/etc/rc.local"*) :
	    fLag="${fLag}p";
    ;;
    ################################## 20201030 #/etc/custom/firstboot/ > was assigned FU
    *"sh/etc/custom/firstboot"*) :
	    fLag="${fLag}C";
    ;;








    *)
        fLag="${fLag}U"


        ;;  #UNKNOWNcaller
esac


































############ WASONHEREMOVEDTOEND
#fLag="${fLag}.${SHLVL}" 	#jumped to 5 6 and 7 on latest built was 2-5?
#if ps w | grep "$PPID" | grep -v grep | grep -q "login"; then fLag="${fLag}.c"; fi



########################### WASON MOVINGLOWER ( end )
#tr -cd '[a-z]'
#fLag="${fLag}.PPID:`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
################################################################


if echo $PS1 | grep -q '@'; then fLag="${fLag}I"; fi #PS1='\w \$ ' or HOME='/' on non-interactive
if echo $HOME | grep -q '/root'; then fLag="${fLag}R"; fi
if [ ! -z "$SSH_TTY" ]; then fLag="${fLag}ssh"; fi


#Wed Feb 17 14:13:58 2021 daemon.notice procd: /etc/rc.d/S19firewall: INTERACTIVE firewall.custom> no via routes... early-firstboot? [exit]










#################################################################################################
#if ps w | grep "$PPID" | grep -v grep | grep -q "login"; then fLag="${fLag}.c"; fi
if ps w | grep "$PPID" | grep -v grep | grep -q "login"; then fLag="${fLag}L"; fi
fLag="${fLag}.${SHLVL}" 	#jumped to 5 6 and 7 on latest built was 2-5?



##############
#fLag="${fLag}.PPID:`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
fLag="${fLag}\#`cat /proc/$PPID/cmdline 2>/dev/null`" 	#jumped to 5 6 and 7 on latest built was 2-5?
#################################################################################################
#message="$fLag: $message"
#caller="$caller:$fLag"






echo $n "${caller}:$fLag> ${message}" >> /tmp/debug-boot-msgs




if [ "$dologmsg" == "y" ]; then logmsg "n: $n caller:${caller} fLag:$fLag> message:${message}"; return 0; fi # -L-logmsg-return
#logmsg "n: $n caller:${caller} message:${message}"



#INTERACTIVE echo stdout > else turned off! ########TESTINGTHISOFFTWOinLOGREADNOPE
#WASON WASON WASON WASON WASON
###############################################################################################################
#if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
###############################################################################################################
#NEWERI if echo $fLag | grep -qE '(I|R)'; then echo $n "${caller}> ${message}"; fi ### ALWAYS straight echo the message
#####################################################################################################################
#999-firstbootcomplete:F.4.PPID:sh/etc/custom/rc.custom2462> finito
#rc.custom:F.3.PPID:sh/etc/rc.local>  ################################### firstboot end 20200826-0457
#rc.local:S.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> no commit:  or nochanges
#rc.local:S.2.PPID:/bin/sh/etc/rc.common/etc/rc.d/S95doneboot> ############################################################## end rc.local
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> datadir: /restorefiles
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> getting gw> attempts remaining: 5 every 3
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> gw-v4> [ok]
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> gw-v6> [ok]
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> NET_DEV4:eth1 NET_ADDR4:100.92.77.184 NET_GW4:100.92.0.1
#checkinternet.sh:S.3.PPID:/bin/bashIRssh> NET_DEV6:eth1 NET_ADDR6:2403:5800:7000:20b:f7b5:dd5e:73bf:935c NET_GW6:fe80::2a2:ff:feb2:c2
#checkinternet.sh:S.2.PPID:-ashIRssh> datadir: /restorefiles
#checkinternet.sh:S.2.PPID:-ashIRssh> getting gw> attempts remaining: 1 every 0
#checkinternet.sh:S.2.PPID:-ashIRssh> gw-v4> [ok]
#checkinternet.sh:S.2.PPID:-ashIRssh> gw-v6> [ok]
#checkinternet.sh:S.2.PPID:-ashIRssh> NET_DEV4:eth1 NET_
#####################################################################################################################





##########if echo $fLag | grep -qE '(I|R)'; then echo INTERACTIVE$n "${caller}> ${message}"; fi
#if echo $fLag | grep -qE '(II)'; then
if echo $fLag | grep -qE '(SIIRL)'; then
    : #CONSOLEANYWAY echo INTERACTIVE$n "${caller}> ${message}"; fi
elif echo $fLag | grep -qE '(I|R)'; then
    echo INTERACTIVE$n "${caller}> ${message}"
    #???????return 0
fi
#Wed Feb 17 14:13:58 2021 daemon.notice procd: /etc/rc.d/S19firewall: INTERACTIVE firewall.custom> no via routes... early-firstboot? [exit]








#if echo $fLag | grep -qE '(I|R)'; then
	######echo $n "${caller}> ${message}"
	######if [ "${wrtlogger}" == "y" ]; then
	######	echo $n "> ${message}" | logger -t "${caller}"
	######fi
	#####echo $n "> ${message}" | logger -t "${caller}"

    #echo "${caller}> ${message}" > /dev/kmsg #echo $n "> ${message}" > /dev/kmsg

#fi






#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#BASGssh FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.
#ASHssh FLAG: SIIRssh.2\#-ash NOT Fall or S
case "${fLag}" in


	##### WORKAROUNDUNTILPERMSGSEPERATECASE-PER_OUTPUT DONOTHINGONCERTAIN MSGS(interactive-for-now)
	################# bash-ssh-interactive FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'
    "SIIRssh"*)
		:
	;;

    "F"*|"S."*|"SC"*|"FC"*)

        #echo "${caller}> ${message}" > /dev/kmsg
        #testkeepingoutofsyslog
        echo "${caller}> ${message}" > /dev/console
    ;;

    *)
        echo $n "${caller}:$fLag> ${message} FLAG: ${fLag} NOT Fall or S." >> /tmp/debug-boot-msgs
    ;;
esac




#NOTINITMSGorSHELLBASED> unknown> 25-dtbomods >>> Compile to ib_path: dtc -I dts -O dtb -o /boot/overlays/led70.dtbo /tmp/led70.dts
#25-dtbomods:FU.5\#sh/etc/custom/firstboot/971-bdrunfboot> kmod-leds-gpio [ok]



#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'


#+ echo 'SIIRssh.3\#/bin/bash'
#+ grep -qE '(I|R)'
#+ echo INTERACTIVE '99-pkgremovetxt> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]'
#INTERACTIVE 99-pkgremovetxt> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh]
#+ echo '99-pkgremovetxt:SIIRssh.3\#/bin/bash> dbg-pkg: zoneinfo-poles wasonlastsystem+andthisone [nope>/tmp/opkgpostinstall.sh] FLAG: SIIRssh.3\#/bin/bash NOT Fall or S.'
#+ read defPK
#+ grep -q ^zoneinfo-southamerica /tmp/instpkg.txt
#+ :







#	sleep $eslp
#sleep $dslp



    #if [ "$silenceECMD" == "y"  ]; then if [ ! -z "$TRACERESTORE"  ]; then TRACERESTORE=; set -x; fi; fi


}









#>&2 echo "------------------- seemetest ----------------------"
#>&2 echo "------------------- seemetest ----------------------"



