<?php


session_start();



	// $noauthcheck = 1;

	$noauthcheck = exec("grep '^YOUTUBEDL_NOAUTH' /root/wrt.ini 2>/dev/null");



	$wedate = exec("date +%Y%m%d%H");
	//echo $wedate;
	$clientip = $_SERVER['REMOTE_ADDR'];
	$authinfo = shell_exec("grep '$clientip$' /tmp/.authlog.$wedate 2>/dev/null");
	
	if (isset($noauthcheck)) { // check we are logged in


		if (empty($noauthcheck)) {

			// echo "noauthcheck: $noauthcheck empty";
			
			if (empty($authinfo)) {
				unset($authinfo);
			}


		} else {
					// THESEAREINVERTEDWESETSOMTHINGIFOK
					// $authinfo = '';
					// unset($authinfo);
			$authinfo = 'noauthcheck';

			// echo "noauthcheck: $noauthcheck";
		}	
		
		
	// } else {
	//	echo "noauthcheck";
		
		
		
	}
		


	if (!isset($authinfo)) { // check we are logged in
					//if (isset($authinfo)) {
					//$authinfo = shell_exec("grep . /tmp/.authlog.$wedate 2>/dev/null");
	
?>
	
	
	
	
	





<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="refresh" content="0; URL=/cgi-bin/luci/" />
</head>
<body style="background-color: white">
<a style="color: black; font-family: arial, helvetica, sans-serif;" href="/cgi-bin/luci/">LuCI - Lua Configuration Interface</a>
</body>
</html>



	
<?php	
	
	
	
	
	
	exit();	
	
	}
	

	//JUSTFORdebugginginverted!isset
	//} else {
	//	echo $authinfo;
	//}





	// echo $authinfo;




?>






<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">

		<title>youtube-dl</title>
		<meta name="viewport" content="initial-scale=1.0">
		
<!--
<link rel="stylesheet" href="/luci-static/bootstrap/cascade.css?v=git-20.168.54559-27fc7a8">
-->

		<link rel="stylesheet" href="cascade.css">
		<link rel="stylesheet" media="only screen and (max-device-width: 854px)" href="/luci-static/bootstrap/mobile.css?v=git-20.168.54559-27fc7a8" type="text/css" />
		<link rel="shortcut icon" href="/luci-static/bootstrap/favicon.png">
	


		<script src="/cgi-bin/luci/admin/translations/en?v=git-20.168.54559-27fc7a8"></script>
		<script src="/luci-static/resources/cbi.js?v=git-20.168.54559-27fc7a8"></script>
	


	</head>




	<body class="lang_en Overview" data-page="admin-status-overview">
		<header>
			<div class="fill">
				<div class="container">
		


					<a class="brand" href="/cgi-bin/luci/admin/status/overview">


<?php

$Hname = exec("cat /proc/sys/kernel/hostname");
echo "$Hname";

?>

</a>

<a href="/cgi-bin/luci/admin/status/overview" target="/cgi-bin/luci/admin/status/overview" title="luci">luci</a>




					<ul class="nav" id="topmenu" style="display:none"></ul>
					<div id="indicators" class="pull-right">


<h3>youtube download</h3>

					</div>

				</div>
			</div>
		</header>




<style>
body{
	background-color:#708890;
	font-family:Arial;
	color:white;
	/* textarea:width='100%'!important; */
}


input, textarea, .uneditable-input, select {
  /* background: url(images/benice.png) center center no-repeat;  This ruins default border */
  border: 1px solid #888; 
  width: '300px' !important;
}




</style>



<center>










<?php
// <p>Paste the URL below, and press GO.</p>
?>













<form action="dl.php" method="post">











<table>
	<tr>

		<td>
<?php
	
if (isset($_SESSION['username'])) { // check we are logged in



?>



	username: <input type="text" name="username" value="<?php echo $_SESSION['username']; ?>">


<?php


} else {


?>

	username: <input type="text" name="username" value="default">

<?php











}

?>







		</td>
		<td align='right' width='70%'>



<!--
<p>
-->


URLvideo: <input type="text" name="url_video" size="39">
<br>
URLaudio: <input type="text" name="url_audio" size="39">
<br>
URLaudioclip: <input type="text" name="url_audio_clip" size="39">
<br>
URLaudioboth: <input type="text" name="url_audio_both" size="39">

<!--
</p>
-->






	</td>
	<td width='30px'>



<input type="submit" value="GO">



	</td>
	</tr>



</form>







	<tr>
		<td colspan=3>
<br>

	</td>
	</tr>
</table>


<?php



// </table>
// <tr colspan=3>
// <td colspan=3>











// NOPE <div width='100%'>
// ############## workedokaboveuntilheaderadd
// </body>
// </html>


// FORMandDL.shNEEDOPTIONforCATEGORYakaditchFOLDERSandgo_custom_NAME or APPENDtocategoryNAME




// #############################################
// echo "$authinfo";
// #############################################


// TOP session_start();
if (isset($_SESSION['username'])) { // check we are logged in
	// echo "session: " . $_SESSION['username'];
}








// $weare = "http://" $_SERVER['SERVER_ADDR']
// $weare = $_SERVER['SERVER_ADDR'] . $_SERVER['REMOTE_PORT'] . $_SERVER['PHP_SELF']
//echo "$weare";





// $stdoud = "/tmp/.dl.sh.stoud";
// if (file_exists($stdoud)) {
//	echo "<p>";
//	$outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '");
//	echo $outputt;
//	echo "</p>";
//}





	// echo "################ inprogress";
	//$outputt = shell_exec("tail -n1 $stdoud 2>/dev/null");
	
	
	
	
	
	
	//              $outputt = shell_exec("cat $stdoud 2>/dev/null | tail -n1");
	// $outputt = shell_exec("echo '' > $stdoud");
	// $outputt = shell_exec("tail -n1 $stdoud 2>/dev/null");
	



	// $outputt = shell_exec("echo '' > $stdoud");
	// $outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | cut -d'[' -f2 | tr -s ']' ' '");		
	// $outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | cut -d'[' -f2 | tr -s ']' ' '");
	#$outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '");
	








	//NOPE echo "<p width='90%'>";
	#NOPE echo "<textarea rows='5' cols='135' width='90%'>";
	
	#NOPE echo "<textarea rows='5' width='90%'>";










	echo "<p>";



	// echo "<textarea rows='5' cols='135'>";
	echo "<textarea rows='5' cols='135' style='none'>";






	#echo "<textarea rows='5' cols='135' width='90%'>";


	// $outputy = shell_exec("/bin/dl.sh -P");		
	#$outputy = shell_exec("/bin/dl.sh -P 2>/dev/null");		
	$outputy = shell_exec("/bin/dl.sh -P 2>/dev/null");		
	// echo "<p>";
	echo $outputy;
	// echo "</p>";
	//<br>

	echo "</textarea>";







	echo "</p>";





	echo "<textarea rows='15' cols='139'>";



	$outputt = shell_exec("/bin/dl.sh printhistory");
	echo $outputt;
	//echo "</p>";

	echo "</textarea>";





?>

<?php
	




//	echo "<p>";
//	$wedate = exec("date +%Y%m%d%H");
//	$clientip = $_SERVER['REMOTE_ADDR'];
//	$authinfo = shell_exec("grep '$clientip$' /tmp/.authlog.$wedate 2>/dev/null");
//	if (isset($authinfo)) {
//		echo "authorized: $authinfo";
//	} else {
//		echo "notauthorized: " . $_SERVER['REMOTE_ADDR'];
//	}
//	echo "</p>";
	
//echo $wedate;




// #############################################
//echo "<p>";
// $outputI = $_SERVER['REMOTE_ADDR'];
// $outputD = shell_exec("date +%Y%m%d%H%M 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 11");
// echo $outputI . "_" . $outputD;
// echo "</p>";
// ##############################################
//echo "c_id:" . $_SERVER['REMOTE_ADDR'];












	// echo "<br>";
	// print_r($_COOKIE);
	// print_r($_COOKIE['sysauth']);

//	foreach ($_COOKIE as $key=>$val)
//  {
//    echo $key.' is '.$val."<br>\n";
//	}


//	var_dump($_COOKIE);

//	echo $_SERVER['HTTP_COOKIE'];
//	echo $HTTP_COOKIE_VARS["sysauth"];










//cookie-domain:10.2.3.1 cookie-name:sysauth 



// $dllog = "/tmp/dllog.txt";
// if (file_exists($dllog)) {
//	$output = shell_exec("tail -n10 $dllog 2>/dev/null");
//	echo "<textarea rows='12' cols='135'>";
//	echo $output;
//	echo "</textarea>";
//}
	// echo "################ completed";

















	// echo $authinfo;
	// $authinfo = shell_exec("grep . /tmp/.authlog.$wedate 2>/dev/null");



// $outputI = shell_exec("echo $REMOTE_ADDR 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo $['REMOTE_ADDR'] 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $REMOTE_ADDR . "2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . "2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | sed 's! !!g'");
#$outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | sed 's! !!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | tr -d ' '");


// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputD = shell_exec("date +%Y%m%d%H%M 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 11");
// echo $outputI . "_" . $outputD;
// echo $outputD;









// $authinfo = shell_exec("cat /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null");
// $authinfo = shell_exec("grep "$_SERVER['REMOTE_ADDR'] " /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null");
// $authinfo = shell_exec("grep $_SERVER['REMOTE_ADDR'] /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null");
//
//
// $authinfo = shell_exec("grep 10.2.3.6 /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null");
//
// $dodo = shell_exec("echo $(date +%Y%m%d%H) > /tmp/.authlog.$(date +%Y%m%d%H) 2>/dev/null");
//
// php has one hour later
// php has one hour later
// $wedate = shell_exec("$(date +%Y%m%d%H)");
// $wedate = shell_exec("$(date +%Y%m%d%H)");
// $authinfo = shell_exec("grep . /tmp/.authlog.$wedate 2>/dev/null");
// php has one hour later
// php has one hour later
//
// $wedate = shell_exec("$(date +%Y%m%d%H)");
// $wedate = shell_exec("`date +%Y%m%d%H`");
//
// $outputD = shell_exec("date +%Y%m%d%H%M 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 11");
// $wedate = shell_exec("date +%Y%m%d%H");
//
// $authinfo = shell_exec("grep " . $_SERVER['REMOTE_ADDR'] . "/tmp/.authlog.$(date +%Y%m%d) 2>/dev/null");
// $authinfo = shell_exec("grep . /tmp/.authlog.$(date +%Y%m%d) 2>/dev/null");
//
// MOVED to exec for wedate













//cat /tmp/.authlog.2021050701








// $outputD = shell_exec("date +%T 2>/dev/null");
// echo $outputD;
// $outputD = shell_exec("date +%T 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 3");







// phpinfo();


	//$noauthcheck = exec("grep '^YOUTUBEDL_NOAUTH' /root/wrt.ini 2>/dev/null");
?>


















</body>
</html>


