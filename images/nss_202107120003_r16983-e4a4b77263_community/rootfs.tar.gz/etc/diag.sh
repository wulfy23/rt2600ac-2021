#!/bin/sh
# Copyright (C) 2015-2016 OpenWrt.org
# Copyright (C) 2017 LEDE project




echD() {


	if [ "$2" = "log" ]; then
		logger -t diag.sh "${1}"
	fi


	if [ ! -z "$DEBUG" ]; then
		echo "${1}" > /dev/console
	fi


}




. /lib/functions.sh
. /lib/functions/leds.sh

set_state() {


	local FN="set_state"

	status_led_default="led1" #@set_state status_led = status_led_default then ...
	status_led_alt_ofN="power"


	if [ -f /root/wrt.ini ]; then
		eval `grep '^RPI4_STATUSLED=' /root/wrt.ini 2>/dev/null`
		if [ ! -z "$RPI4_STATUSLED"  ]; then
			SETSTATEMSG="${SETSTATEMSG} ini-fOK-${RPI4_STATUSLED}"
		else
			SETSTATEMSG="${SETSTATEMSG} ini-fOK-RPI_STATUSLED[unset]"
		fi
	else
		SETSTATEMSG="${SETSTATEMSG} iniNO"
	fi








    case "$(board_name)" in
    raspberrypi,2-model-b |\
	raspberrypi,2-model-b-rev2 |\
	raspberrypi,3-model-b |\
	raspberrypi,3-model-b-plus |\
	raspberrypi,400 |\
	raspberrypi,4-compute-module |\
	raspberrypi,4-model-b |\
	raspberrypi,model-b-plus)




		#@resolve-early-to-handle-logic-better
		status_led_alt_ofP=$(dirname $(grep -l 'OF_NAME=power' /sys/devices/platform/leds/leds/*/uevent 2>/dev/null) 2>/dev/null)
		if [ ! -z "$status_led_alt_ofP" ]; then
			status_led_alt_ofL="$(basename $status_led_alt_ofP)" #!MAINIFSETVAR
			SETSTATEMSG="${SETSTATEMSG} OF-${status_led_alt_ofN}-${status_led_alt_ofL}"
			#VERB echD "RPI4_STATUSLEDOF($status_led_alt_ofN) status_led_alt_ofL:$status_led_alt_ofL status_led_alt_ofP:$status_led_alt_ofP"
		else
			SETSTATEMSG="${SETSTATEMSG} OF-${status_led_alt_ofN}-no"
			#VERB echD "RPI4_STATUSLED OF status_led_alt_ofN:$status_led_alt_ofN [no-dts-references]"
		fi #status_led_alt_ofL:$of_alt_ledP #echo $status_led > /tmp/.of_led



		if [ ! -z "$RPI4_STATUSLED"  ]; then #if [ ! -z "$RPI4_STATUSLED"  ]; then status_led="$RPI4_STATUSLED"; fi
			status_led="$RPI4_STATUSLED"
			#@SUMMARY echD "DBG-RPI4_STATUSLED(fromINI) $status_led"
		else
			:
			#echo "RPI4_STATUSLED ini nope $(cat /proc/$PPID/cmdline 2>/dev/null)" > /dev/console

			#NOTE POWER NEEDS TO BE HARDCODED
			#NOTE THIS ALSO WILL WRECK/EFFECT dual statuses re: frontisinitialize and power is failsafe
			#NOTE this is handy for disabling i.e. does not parse existing ofnode on upgrade (probably fbootearlytho)
			#yup stuffs up and initialize status are inverted -> only other way to disable OF = cmdline append?
			#now the OF doesnt get disabled
			#break out the OFlogic



			if [ ! -f /root/wrt.ini ]; then
				#couldset IS_FBOOT here
				if [ ! -z "$status_led_alt_ofL" ]; then



					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					: #status_led=$status_led_alt_ofL
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF
					#!!!UNTILTHISISFIXED DEFAULT DONT USE OF

					echD "RPI4_STATUSLED(earlyupgrdefromOFpower) $status_led" #echo $status_led > /tmp/.of_led
				else
					echD "DBG-RPI4_STATUSLED(earlyupgrdefromOFpower) [no-power-leds-in-of]"
				fi

			fi

		fi

















		#status_led="${status_led:-"led1"}"
		#see if this hackily activates whatever handline already exists in functions/leds.sh i.e. assign regular to this val
		#note had a bug at initialize was sending to led1 status_led2 probably better anyway
		#status_led2="led1"

		if [ -z "$status_led" ]; then

			status_led="${status_led:-"$status_led_default"}" #USEDEFAULTVALUE


			#HACKYWORKAROUDFOROF_LEDPICKEDUPDURINGUPGRADEBUTNOTENABLEDinWRTINI HOPEFULLY FOR NOW WILL ATTEMPT TO MIRRORANDTURNOFF
			#TECHNICALLYdetectfboot@upgrade||readablewrt.iniandnotsetthenturnofforswitchnow... PITA
			if [ -f /tmp/.of_led ]; then
				status_led2="$(cat /tmp/.of_led 2>/dev/null)"
			fi


		else
			status_led2="$status_led_default" #WESETONEOFOURS->SETstatus_led2-to-the-defaultoptional
		fi















		if [ ! -z "$DEBUGv" ]; then #echD "$FN params:${*} $SETSTATEMSG"
			echD "$FN-dbg-funcparams> ${*} PPIDcmd:$(cat /proc/$PPID/cmdline) \$\$cmd: $(cat /proc/$$/cmdline)"
			echD "$FN-SUMMARY> params:${*} $SETSTATEMSG"
		fi

		#echD "$FN-SUMMARY> params:${*} $SETSTATEMSG" log


		#FINALDEBUG if [ ! -z "$DEBUG" ]; then
		echD "$FN status_led_default:$status_led_default status_led:$status_led status_led2:$status_led2"




		#########




		;;




	raspberrypi,3-compute-module |\
	raspberrypi,model-b |\
	raspberrypi,model-zero |\
	raspberrypi,model-zero-w)
		status_led="led0"
		;;
	esac









	####################### HACKYEARLYHANDLERSFORCASETOMIMICKPREINITCALLSALSO
	#LEAVEOFFCOULDBE-OF-EARLYBOOT
	#case "$1" in
	#preinit)
	#	status_led_blink_preinit
	#	;;
	#failsafe)
	#	status_led_blink_failsafe
	#	;;
	#preinit_regular)
	#	status_led_blink_preinit_regular
	#	;;
	#esac


	########






	case "$1" in
	###########################################
    initialize) #status_led_blink_initialize
        status_led_blink_initialize "$2"
    ;;
    upgrade) #NOTE "upgrade" is not in this target yet
        status_led_blink_initialize "upgrade"
	;;
	###########################################



	preinit) #/lib/preinit/10_indicate_preinit:set_state preinit #status_led_blink_preinit
		status_led_blink_preinit
		;;


	failsafe) #status_led_blink_failsafe #@preinit/10_failsafe


		#NONEWORK?CHECKATTOP-FN-CALL
		#echo "#@@@@@@@@@@@@ diag.shDBG5> status_led_blink_failsafe SET -x" >/dev/console
		#echo "#@@@@@@@@@@@@ diag.shDBG5> status_led_blink_failsafe SET -x" >/dev/kmsg
		#BREAKS init? echos above? set -x


		status_led_blink_failsafe




		;;
	preinit_regular) #status_led_blink_preinit_regular

		status_led_blink_preinit_regular

		;;


	"done")

		status_led_on

		#ABOVEDOESNOTSEEMTOWORKWITH RPI4_STATUSLED=ledX add done
        status_led_blink_initialize "done"
		#NOTE hack@status_led2 on set status_led turning main off either that or this not sure which one

		;;
	esac



}













#THEBASEBITS


#20210215 ./build_dir/target-aarch64_cortex-a72_musl/root.orig-bcm27xx/etc/diag.sh + lib/functions/leds.sh @ init.d/done











################################
#stage2 indicate_upgrade() {
#	. /etc/diag.sh
#	set_state upgrade
#}
################################



#/lib/preinit/02_default_set_state:define_default_set_state() {
#/lib/preinit/02_default_set_state:boot_hook_add preinit_main define_default_set_state
#/lib/preinit/10_indicate_failsafe:set_s	tate failsafe
#/lib/preinit/10_indicate_preinit:set_state preinit
#/lib/	preinit/50_indicate_regular_preinit:set_state preinit_regular











		#BECAUSE-ONUPGRADE-ROOT_WRT.INI HAS NOT BEEN UNPACKED YET
		#COULDWALKPROC-OF-FOR-LABEL-fpwr


		#RPI4_STATUSLED led18 /sbin/procd @
#[    3.953967 ]  sdc: sdc1 sdc2 sdc3
#[    3.958625 ] sd 1:0:0:0: [sdc] Attached SCSI removable disk
#[    4.290614 ] fsckparts bootpart:/dev/sdb1 [clean]
#[    4.533756 ] fsckparts rootfspart:/dev/sdb2 [clean]
#[    4.620005 ] bcmgenet: Skipping UMAC reset
#[    4.625608 ] bcmgenet fd580000.ethernet: configuring instance for external RGMII
#[    4.633501 ] bcmgenet fd580000.ethernet eth0: Link is Down

#RPI4_STATUSLED ini nope /sbin/initfsckparts

#Press the [f] key and hit [enter] to enter failsafe mode
#Press the [1], [2], [3] or [4] key and hit [enter] to select the debug level

#RPI4_STATUSLED ini nope /sbin/initfsckparts

#[    8.702244 ] mount_root: mounting /dev/root
#[    9.549684 ] EXT4-fs (sdb2): re-mounted. Opts: (null)
#[    9.554847 ] mount_root: loading kmods from internal overlay




#[   54.710926 ] usbserial: USB Serial support registered for Qualcomm USB modem
#[   54.718042 ] kmodloader: done loading kernel modules from /etc/modules.d/*
#[   56.118766 ] EXT4-fs (sdc2): mounted filesystem with ordered data mode. Opts:
#[   58.368462 ]  welcomeback localversion="2.7.75-23" > localversion="2.7.75-25"

#RPI4_STATUSLED led18 /sbin/procd

#[   64.453025 ] bcmgenet fd580000.ethernet eth0: Link is Up - 1Gbps/Full - flow control rx/tx
#[   64.461445 ] br-lan: port 1(eth0) entered blocking state












#status_led=$(basename $(dirname $(grep -l 'OF_NAME=power' /sys/devices/platform/leds/leds/*/uevent)))




#!NOVALIDATIONPERFORMED #NOTE: status_led2 @ functions/leds.sh
#MOVEDTOTOP eval `grep '^RPI4_STATUSLED=' /root/wrt.ini 2>/dev/null`

















